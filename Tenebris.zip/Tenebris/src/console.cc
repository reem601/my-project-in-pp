#include "src/console.h"

#include <cstddef>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

#include "src/text_util.h"

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#endif

namespace tenebris {
namespace console {

void Initialize() {
#ifdef _WIN32
  SetConsoleOutputCP(CP_UTF8);
  SetConsoleCP(CP_UTF8);
  SetConsoleTitleA("Tenebris");
#endif
  std::ios::sync_with_stdio(false);
}

void Print(const std::string& text) {
  if (text.empty()) {
    PrintBlank();
    return;
  }
  const std::vector<std::string> lines = text_util::Wrap(text, kLineWidth);
  for (const std::string& line : lines) {
    std::cout << line << '\n';
  }
}

void PrintRaw(const std::string& text) { std::cout << text << '\n'; }

void PrintBlank() { std::cout << '\n'; }

void PrintRule() { std::cout << std::string(kLineWidth, '-') << '\n'; }

void PrintGauge(const std::string& label, int value, int max_value) {
  constexpr int kCells = 20;
  if (max_value <= 0) return;
  const int clamped = value < 0 ? 0 : (value > max_value ? max_value : value);
  const int filled = clamped * kCells / max_value;
  std::string bar;
  for (int i = 0; i < kCells; ++i) bar += (i < filled ? "#" : ".");
  std::cout << label << " [" << bar << "] " << clamped << "/" << max_value
            << '\n';
}

bool ReadLine(std::string* line) {
  std::cout.flush();
  if (!std::getline(std::cin, *line)) return false;
  // Strip the carriage return left by Windows style line endings when the
  // game is fed from a redirected file.
  if (!line->empty() && line->back() == '\r') line->pop_back();
  return true;
}

void WaitForEnter(const std::string& prompt) {
  std::cout << prompt;
  std::cout.flush();
  std::string ignored;
  std::getline(std::cin, ignored);
}

void Clear() {
#ifdef _WIN32
  std::system("cls");
#else
  std::cout << "\033[2J\033[H";
#endif
}

}  // namespace console
}  // namespace tenebris
