#include "src/inventory.h"

#include <string>
#include <vector>

#include "src/item.h"
#include "src/player.h"

namespace tenebris {

void Inventory::AddItem(const Item& item) { items_.push_back(item); }

bool Inventory::RemoveItem(const std::string& id) {
  for (std::vector<Item>::iterator it = items_.begin(); it != items_.end();
       ++it) {
    if (it->id() == id) {
      items_.erase(it);
      return true;
    }
  }
  return false;
}

bool Inventory::Has(const std::string& id) const { return Find(id) != nullptr; }

const Item* Inventory::Find(const std::string& id) const {
  for (const Item& item : items_) {
    if (item.id() == id) return &item;
  }
  return nullptr;
}

bool Inventory::UseItem(const std::string& id, Player* player,
                        std::string* message) {
  const Item* item = Find(id);
  if (item == nullptr || !item->usable()) return false;
  // Copy first: applying the effect may remove the item from the vector.
  const Item copy = *item;
  *message = copy.Use(player);
  if (copy.consumable()) RemoveItem(id);
  return true;
}

}  // namespace tenebris
