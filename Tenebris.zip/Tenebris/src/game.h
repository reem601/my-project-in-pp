// Entry point of the game: owns the content, the heroine and the systems
// that drive a run.

#ifndef TENEBRIS_SRC_GAME_H_
#define TENEBRIS_SRC_GAME_H_

#include <string>

#include "src/combat_system.h"
#include "src/content_database.h"
#include "src/dialogue.h"
#include "src/ending_manager.h"
#include "src/player.h"

namespace tenebris {

class Game {
 public:
  Game() = default;

  Game(const Game&) = delete;
  Game& operator=(const Game&) = delete;

  // Loads content/, shows the main menu and plays until the player leaves.
  // Returns false when the content could not be loaded.
  bool Start(const std::string& content_dir_hint);

 private:
  enum class MenuCommand { kNewGame, kAbout, kQuit };

  // Reads the main menu selection.
  MenuCommand ProcessInput();

  // Plays the chapters one after another until an ending is reached.
  void GameLoop();

  // Settles the run state between chapters and decides whether the story
  // can continue.
  void Update();

  void ShowTitleScreen() const;
  void ShowAbout() const;

  ContentDatabase content_;
  Dialogue dialogue_{&content_};
  CombatSystem combat_{&content_, &dialogue_};
  EndingManager endings_{&content_, &dialogue_};
  Player player_;

  // Ending chosen by the story; "auto" defers to the EndingManager.
  std::string pending_ending_;
  bool running_ = false;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_GAME_H_
