#include "src/story_manager.h"

#include <memory>

#include "src/chapter.h"

namespace tenebris {

std::unique_ptr<Chapter> StoryManager::NextChapter() {
  if (!HasNext()) return nullptr;
  std::unique_ptr<Chapter> chapter(
      new Chapter(content_->chapters()[index_], context_));
  ++index_;
  return chapter;
}

}  // namespace tenebris
