#include "src/game.h"

#include <memory>
#include <string>
#include <vector>

#include "src/chapter.h"
#include "src/console.h"
#include "src/content_database.h"
#include "src/dialogue.h"
#include "src/game_context.h"
#include "src/player.h"
#include "src/story_manager.h"

namespace tenebris {
namespace {

// A pause between chapters lets the heroine catch her breath.
constexpr int kBetweenChapterHp = 25;
constexpr int kBetweenChapterMental = 10;

}  // namespace

void Game::ShowTitleScreen() const {
  console::Clear();
  const std::vector<std::string> banner = content_.TextList("title_banner");
  for (const std::string& line : banner) {
    console::PrintRaw(line);
  }
  console::PrintBlank();
  dialogue_.ShowUi("title_subtitle");
}

void Game::ShowAbout() const {
  console::PrintBlank();
  const std::vector<std::string> lines = content_.TextList("about");
  for (const std::string& line : lines) {
    console::Print(line);
  }
  console::PrintBlank();
}

Game::MenuCommand Game::ProcessInput() {
  std::vector<ChoiceOption> options;
  ChoiceOption new_game;
  new_game.text = content_.Text("menu_new_game");
  ChoiceOption about;
  about.text = content_.Text("menu_about");
  ChoiceOption quit;
  quit.text = content_.Text("menu_quit");
  options.push_back(new_game);
  options.push_back(about);
  options.push_back(quit);

  const int index = dialogue_.PresentChoices(options, &player_);
  if (index == Dialogue::kQuitRequested || index == 2) {
    return MenuCommand::kQuit;
  }
  return index == 0 ? MenuCommand::kNewGame : MenuCommand::kAbout;
}

void Game::Update() {
  if (!player_.alive() || player_.broken()) {
    pending_ending_ = "auto";
    running_ = false;
    return;
  }
  player_.ChangeHp(kBetweenChapterHp);
  player_.ChangeMental(kBetweenChapterMental);
  dialogue_.ShowStatus(player_);
  console::WaitForEnter(content_.Text("press_enter"));
}

void Game::GameLoop() {
  player_ = Player();
  pending_ending_.clear();
  running_ = true;

  GameContext context;
  context.content = &content_;
  context.dialogue = &dialogue_;
  context.combat = &combat_;

  StoryManager story(&content_, context);
  while (running_ && story.HasNext()) {
    const std::unique_ptr<Chapter> chapter = story.NextChapter();
    const ChapterResult result = chapter->Start(&player_);
    if (result.outcome == ChapterOutcome::kQuit) {
      running_ = false;
      return;
    }
    if (result.outcome == ChapterOutcome::kEnding) {
      pending_ending_ = result.ending_id;
      running_ = false;
      break;
    }
    Update();
  }

  const std::string ending_id =
      (pending_ending_.empty() || pending_ending_ == "auto")
          ? endings_.DetermineEnding(player_)
          : pending_ending_;
  endings_.ShowEnding(ending_id, player_);
  console::WaitForEnter(content_.Text("press_enter"));
}

bool Game::Start(const std::string& content_dir_hint) {
  std::string content_dir;
  if (!LocateContentDir(content_dir_hint, &content_dir)) {
    console::PrintRaw(
        "Content directory not found. Run the game from the project "
        "directory or pass the path to content/ as the first argument.");
    return false;
  }
  std::string error;
  if (!content_.Load(content_dir, &error)) {
    console::PrintRaw("Failed to load content: " + error);
    return false;
  }

  ShowTitleScreen();
  while (true) {
    switch (ProcessInput()) {
      case MenuCommand::kNewGame:
        GameLoop();
        if (dialogue_.quit_requested()) return true;
        ShowTitleScreen();
        break;
      case MenuCommand::kAbout:
        ShowAbout();
        break;
      case MenuCommand::kQuit:
        dialogue_.ShowUi("farewell");
        return true;
    }
  }
}

}  // namespace tenebris
