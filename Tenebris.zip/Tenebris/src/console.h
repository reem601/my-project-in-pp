// Thin platform layer over the text console: UTF-8 setup, word wrapped
// output and line input.

#ifndef TENEBRIS_SRC_CONSOLE_H_
#define TENEBRIS_SRC_CONSOLE_H_

#include <cstddef>
#include <string>

namespace tenebris {
namespace console {

// Width used for word wrapping narrative text.
constexpr std::size_t kLineWidth = 72;

// Switches the Windows console to UTF-8 so that Cyrillic content renders
// correctly; a no-op on other platforms.
void Initialize();

// Prints `text` wrapped to kLineWidth, followed by a line break.
void Print(const std::string& text);

// Prints `text` as is, without wrapping.
void PrintRaw(const std::string& text);

void PrintBlank();

// Horizontal separator used between scenes.
void PrintRule();

// Renders a labelled gauge, for example "HP  [########--] 80/100".
void PrintGauge(const std::string& label, int value, int max_value);

// Reads one line; returns false when the input stream is exhausted.
bool ReadLine(std::string* line);

// Waits for the player to press Enter.
void WaitForEnter(const std::string& prompt);

void Clear();

}  // namespace console
}  // namespace tenebris

#endif  // TENEBRIS_SRC_CONSOLE_H_
