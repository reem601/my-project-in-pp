// Глава 4. Лес Иллюзий.
// Разгаданная загадка открывает короткий путь; иначе — блуждание и бой.

Tenebris.content.chapter_4 = {
  id: "chapter_4",
  title: "Глава 4. Лес Иллюзий",
  start: "forest_edge",

  intro: [
    "Лес начинается сразу, без опушки: только что был коридор — и вот уже",
    "стволы со всех сторон. Деревья стоят слишком ровно, как расставленные."
  ],

  nodes: [
    {
      id: "forest_edge",
      text: [
        "Тропа раздваивается, потом растраивается, потом сходится обратно",
        "в ту же точку. На развилке — столб с тремя стрелками без надписей."
      ],
      next: "forest_puzzle"
    },

    {
      id: "forest_puzzle",
      type: "puzzle",
      puzzle: "forest_riddle",
      on_solve: "forest_true_path",
      on_fail: "forest_maze"
    },

    {
      id: "forest_true_path",
      text: [
        "Вы идёте туда, куда показала стрелка, и лес перестаёт спорить.",
        "Иллюзии всё ещё зовут с обочины, но вы больше не оборачиваетесь."
      ],
      on_enter: {
        mental: 8
      },
      next: "forest_clearing"
    },

    {
      id: "forest_maze",
      text: [
        "Вы выбираете направление наугад."
      ],
      revisit_text: [
        "Тропа снова вывела вас к тому же столбу. Стрелки не изменились."
      ],
      choices: [
        {
          text: "Свернуть влево, на треск веток",
          next: "forest_loop_a"
        },
        {
          text: "Свернуть вправо, на просвет",
          next: "forest_stalker_fight"
        },
        {
          text: "Идти прямо, никуда не сворачивая",
          next: "forest_loop_b"
        }
      ]
    },

    {
      id: "forest_loop_a",
      text: [
        "Треск оказывается вашими же шагами, отражёнными от чего-то",
        "в темноте. Вы продираетесь через ежевику и выходите не туда."
      ],
      on_enter: {
        hp: -8
      },
      next: "forest_stalker_fight"
    },

    {
      id: "forest_loop_b",
      text: [
        "Прямая тропа поворачивает у вас за спиной. Дважды.",
        "Голос Элиана окликает вас справа, потом слева, потом сверху."
      ],
      on_enter: {
        mental: -10
      },
      next: "forest_stalker_fight"
    },

    {
      id: "forest_stalker_fight",
      text: [
        "Ветви перед вами сплетаются в фигуру выше человека."
      ],
      type: "combat",
      enemy: "forest_stalker",
      on_win: "forest_clearing",
      on_win_effects: {
        mental: 10
      },
      on_lose: "forest_clearing",
      on_lose_effects: {
        hp: -5,
        text: ["Вы вырываетесь и бежите, пока лес не отстаёт сам."]
      },
      revive_hp: 25,
      revive_mental: 20
    },

    {
      id: "forest_clearing",
      text: [
        "Лес кончается обрывом. Внизу, в долине без дна, стоит Башня —",
        "чёрная, узкая, с одним освещённым окном на самом верху.",
        "",
        "Компас в кармане поворачивается и указывает точно на неё."
      ],
      on_enter: {
        give: ["apple", "small_crystal"],
        set: ["saw_tower"]
      },
      next: "chapter_4_end"
    },

    {
      id: "chapter_4_end",
      type: "chapter_end"
    }
  ]
};
