#include "src/js_parser.h"

#include <cctype>
#include <cstddef>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <utility>

#include "src/js_value.h"
#include "src/text_util.h"

namespace tenebris {
namespace js_parser {
namespace {

// Guards against pathological nesting in a hand edited content file.
constexpr int kMaxDepth = 64;

bool IsIdentifierStart(char byte) {
  const unsigned char value = static_cast<unsigned char>(byte);
  return std::isalpha(value) != 0 || byte == '_' || byte == '$';
}

bool IsIdentifierPart(char byte) {
  const unsigned char value = static_cast<unsigned char>(byte);
  return std::isalnum(value) != 0 || byte == '_' || byte == '$';
}

class Parser {
 public:
  Parser(const std::string& source, const std::string& file_name)
      : source_(source), file_name_(file_name) {}

  bool ParseAssignment(JsValue* out, std::string* error);

 private:
  bool Eof() const { return pos_ >= source_.size(); }
  char Peek() const { return Eof() ? '\0' : source_[pos_]; }
  char PeekAt(std::size_t offset) const {
    return pos_ + offset >= source_.size() ? '\0' : source_[pos_ + offset];
  }
  void Advance();
  void SkipTrivia();
  bool Expect(char expected);

  bool ParseValue(JsValue* out);
  bool ParseObject(JsValue* out);
  bool ParseArray(JsValue* out);
  bool ParseString(std::string* out);
  bool ParseNumber(JsValue* out);
  bool ParseLiteral(JsValue* out);
  bool ParseIdentifier(std::string* out);

  bool Fail(const std::string& message);
  static void AppendUtf8(unsigned int code_point, std::string* out);

  const std::string& source_;
  const std::string file_name_;
  std::size_t pos_ = 0;
  int line_ = 1;
  int column_ = 1;
  int depth_ = 0;
  std::string error_;
};

void Parser::Advance() {
  if (Eof()) return;
  if (source_[pos_] == '\n') {
    ++line_;
    column_ = 1;
  } else {
    ++column_;
  }
  ++pos_;
}

void Parser::SkipTrivia() {
  while (!Eof()) {
    const char current = Peek();
    if (std::isspace(static_cast<unsigned char>(current)) != 0) {
      Advance();
      continue;
    }
    if (current == '/' && PeekAt(1) == '/') {
      while (!Eof() && Peek() != '\n') Advance();
      continue;
    }
    if (current == '/' && PeekAt(1) == '*') {
      Advance();
      Advance();
      while (!Eof() && !(Peek() == '*' && PeekAt(1) == '/')) Advance();
      Advance();
      Advance();
      continue;
    }
    return;
  }
}

bool Parser::Expect(char expected) {
  SkipTrivia();
  if (Peek() != expected) {
    return Fail(std::string("expected '") + expected + "'");
  }
  Advance();
  return true;
}

bool Parser::Fail(const std::string& message) {
  if (error_.empty()) {
    error_ = file_name_ + ":" + text_util::FromInt(line_) + ":" +
             text_util::FromInt(column_) + ": " + message;
  }
  return false;
}

void Parser::AppendUtf8(unsigned int code_point, std::string* out) {
  if (code_point < 0x80) {
    out->push_back(static_cast<char>(code_point));
  } else if (code_point < 0x800) {
    out->push_back(static_cast<char>(0xC0 | (code_point >> 6)));
    out->push_back(static_cast<char>(0x80 | (code_point & 0x3F)));
  } else if (code_point < 0x10000) {
    out->push_back(static_cast<char>(0xE0 | (code_point >> 12)));
    out->push_back(static_cast<char>(0x80 | ((code_point >> 6) & 0x3F)));
    out->push_back(static_cast<char>(0x80 | (code_point & 0x3F)));
  } else {
    out->push_back(static_cast<char>(0xF0 | (code_point >> 18)));
    out->push_back(static_cast<char>(0x80 | ((code_point >> 12) & 0x3F)));
    out->push_back(static_cast<char>(0x80 | ((code_point >> 6) & 0x3F)));
    out->push_back(static_cast<char>(0x80 | (code_point & 0x3F)));
  }
}

bool Parser::ParseIdentifier(std::string* out) {
  SkipTrivia();
  if (!IsIdentifierStart(Peek())) return Fail("expected an identifier");
  out->clear();
  while (!Eof() && IsIdentifierPart(Peek())) {
    out->push_back(Peek());
    Advance();
  }
  return true;
}

bool Parser::ParseString(std::string* out) {
  const char quote = Peek();
  if (quote != '"' && quote != '\'') return Fail("expected a string");
  Advance();
  out->clear();
  while (true) {
    if (Eof()) return Fail("unterminated string");
    const char current = Peek();
    if (current == quote) {
      Advance();
      return true;
    }
    if (current != '\\') {
      out->push_back(current);
      Advance();
      continue;
    }
    Advance();
    const char escape = Peek();
    Advance();
    switch (escape) {
      case 'n':
        out->push_back('\n');
        break;
      case 't':
        out->push_back('\t');
        break;
      case 'r':
        break;
      case 'u': {
        unsigned int code_point = 0;
        for (int i = 0; i < 4; ++i) {
          const char digit = Peek();
          if (std::isxdigit(static_cast<unsigned char>(digit)) == 0) {
            return Fail("malformed \\u escape");
          }
          const unsigned int value =
              std::isdigit(static_cast<unsigned char>(digit)) != 0
                  ? static_cast<unsigned int>(digit - '0')
                  : static_cast<unsigned int>(
                        std::tolower(static_cast<unsigned char>(digit)) - 'a' +
                        10);
          code_point = code_point * 16 + value;
          Advance();
        }
        // Combine a UTF-16 surrogate pair into a single code point.
        if (code_point >= 0xD800 && code_point <= 0xDBFF && Peek() == '\\' &&
            PeekAt(1) == 'u') {
          Advance();
          Advance();
          unsigned int low = 0;
          for (int i = 0; i < 4; ++i) {
            const char digit = Peek();
            if (std::isxdigit(static_cast<unsigned char>(digit)) == 0) {
              return Fail("malformed \\u escape");
            }
            const unsigned int value =
                std::isdigit(static_cast<unsigned char>(digit)) != 0
                    ? static_cast<unsigned int>(digit - '0')
                    : static_cast<unsigned int>(
                          std::tolower(static_cast<unsigned char>(digit)) -
                          'a' + 10);
            low = low * 16 + value;
            Advance();
          }
          code_point = 0x10000 + ((code_point - 0xD800) << 10) + (low - 0xDC00);
        }
        AppendUtf8(code_point, out);
        break;
      }
      default:
        out->push_back(escape);
        break;
    }
  }
}

bool Parser::ParseNumber(JsValue* out) {
  const std::size_t start = pos_;
  if (Peek() == '-' || Peek() == '+') Advance();
  while (std::isdigit(static_cast<unsigned char>(Peek())) != 0) Advance();
  if (Peek() == '.') {
    Advance();
    while (std::isdigit(static_cast<unsigned char>(Peek())) != 0) Advance();
  }
  if (Peek() == 'e' || Peek() == 'E') {
    Advance();
    if (Peek() == '-' || Peek() == '+') Advance();
    while (std::isdigit(static_cast<unsigned char>(Peek())) != 0) Advance();
  }
  if (pos_ == start) return Fail("expected a number");
  const std::string text = source_.substr(start, pos_ - start);
  *out = JsValue::Number(std::strtod(text.c_str(), nullptr));
  return true;
}

bool Parser::ParseLiteral(JsValue* out) {
  std::string word;
  if (!ParseIdentifier(&word)) return false;
  if (word == "true") {
    *out = JsValue::Bool(true);
    return true;
  }
  if (word == "false") {
    *out = JsValue::Bool(false);
    return true;
  }
  if (word == "null" || word == "undefined") {
    *out = JsValue();
    return true;
  }
  return Fail("unexpected identifier '" + word + "'");
}

bool Parser::ParseArray(JsValue* out) {
  if (!Expect('[')) return false;
  *out = JsValue::Array();
  while (true) {
    SkipTrivia();
    if (Peek() == ']') {
      Advance();
      return true;
    }
    JsValue element;
    if (!ParseValue(&element)) return false;
    out->Append(std::move(element));
    SkipTrivia();
    if (Peek() == ',') {
      Advance();
      continue;
    }
    if (Peek() == ']') {
      Advance();
      return true;
    }
    return Fail("expected ',' or ']'");
  }
}

bool Parser::ParseObject(JsValue* out) {
  if (!Expect('{')) return false;
  *out = JsValue::Object();
  while (true) {
    SkipTrivia();
    if (Peek() == '}') {
      Advance();
      return true;
    }
    std::string key;
    if (Peek() == '"' || Peek() == '\'') {
      if (!ParseString(&key)) return false;
    } else if (!ParseIdentifier(&key)) {
      return false;
    }
    if (!Expect(':')) return false;
    JsValue member;
    if (!ParseValue(&member)) return false;
    out->Set(std::move(key), std::move(member));
    SkipTrivia();
    if (Peek() == ',') {
      Advance();
      continue;
    }
    if (Peek() == '}') {
      Advance();
      return true;
    }
    return Fail("expected ',' or '}'");
  }
}

bool Parser::ParseValue(JsValue* out) {
  if (depth_ >= kMaxDepth) return Fail("content nested too deeply");
  SkipTrivia();
  if (Eof()) return Fail("unexpected end of file");
  const char current = Peek();
  ++depth_;
  bool ok = false;
  if (current == '{') {
    ok = ParseObject(out);
  } else if (current == '[') {
    ok = ParseArray(out);
  } else if (current == '"' || current == '\'') {
    std::string text;
    ok = ParseString(&text);
    // A run of quoted pieces joined by '+' is one string. This keeps long
    // narrative lines readable inside the content files.
    while (ok) {
      SkipTrivia();
      if (Peek() != '+') break;
      Advance();
      SkipTrivia();
      if (Peek() != '"' && Peek() != '\'') {
        ok = Fail("expected a string after '+'");
        break;
      }
      std::string continuation;
      ok = ParseString(&continuation);
      if (ok) text += continuation;
    }
    if (ok) *out = JsValue::String(std::move(text));
  } else if (current == '-' || current == '+' ||
             std::isdigit(static_cast<unsigned char>(current)) != 0) {
    ok = ParseNumber(out);
  } else {
    ok = ParseLiteral(out);
  }
  --depth_;
  return ok;
}

bool Parser::ParseAssignment(JsValue* out, std::string* error) {
  // Skip an optional UTF-8 byte order mark left by Windows editors.
  if (source_.size() >= 3 && static_cast<unsigned char>(source_[0]) == 0xEF &&
      static_cast<unsigned char>(source_[1]) == 0xBB &&
      static_cast<unsigned char>(source_[2]) == 0xBF) {
    pos_ = 3;
  }
  std::string segment;
  if (!ParseIdentifier(&segment)) {
    *error = error_;
    return false;
  }
  while (true) {
    SkipTrivia();
    if (Peek() != '.') break;
    Advance();
    if (!ParseIdentifier(&segment)) {
      *error = error_;
      return false;
    }
  }
  if (!Expect('=') || !ParseValue(out)) {
    *error = error_;
    return false;
  }
  SkipTrivia();
  if (Peek() == ';') Advance();
  SkipTrivia();
  if (!Eof()) {
    Fail("unexpected trailing content");
    *error = error_;
    return false;
  }
  return true;
}

}  // namespace

bool ParseAssignment(const std::string& source, const std::string& file_name,
                     JsValue* out, std::string* error) {
  Parser parser(source, file_name);
  return parser.ParseAssignment(out, error);
}

bool ParseFile(const std::string& path, JsValue* out, std::string* error) {
  std::ifstream stream(path.c_str(), std::ios::binary);
  if (!stream.is_open()) {
    *error = "cannot open content file: " + path;
    return false;
  }
  std::ostringstream buffer;
  buffer << stream.rdbuf();
  return ParseAssignment(buffer.str(), path, out, error);
}

}  // namespace js_parser
}  // namespace tenebris
