// One chapter of the story, driven by the node graph declared in
// content/chapters/chapter_N.js.

#ifndef TENEBRIS_SRC_CHAPTER_H_
#define TENEBRIS_SRC_CHAPTER_H_

#include <set>
#include <string>

#include "src/game_context.h"
#include "src/js_value.h"

namespace tenebris {

class Player;

enum class ChapterOutcome {
  kCompleted,  // The chapter ran to its end; the story continues.
  kEnding,     // The chapter jumped straight to an ending.
  kQuit,       // The player left the game.
};

struct ChapterResult {
  ChapterOutcome outcome = ChapterOutcome::kCompleted;
  // Filled for kEnding; "auto" asks the EndingManager to decide.
  std::string ending_id;
};

class Chapter {
 public:
  Chapter(const JsValue& def, const GameContext& context);

  const std::string& id() const { return id_; }
  const std::string& title() const { return title_; }

  // Walks the node graph until the chapter ends.
  ChapterResult Start(Player* player);

 private:
  const JsValue& FindNode(const std::string& node_id) const;

  // Applies an effects block: gauges, items, flags and a line of text.
  void ApplyEffects(const JsValue& effects, Player* player);

  // True when the player meets every requirement of `choice`.
  bool IsChoiceAvailable(const JsValue& choice, const Player& player) const;

  // Handlers for the node kinds; each returns the next node id, or an empty
  // string when the chapter is over. `result` is filled when the node ends
  // the run.
  std::string RunCombatNode(const JsValue& node, Player* player,
                            ChapterResult* result);
  std::string RunPuzzleNode(const JsValue& node, Player* player,
                            ChapterResult* result);
  std::string RunSceneNode(const JsValue& node, Player* player,
                           ChapterResult* result);

  const JsValue& def_;
  GameContext context_;
  std::string id_;
  std::string title_;
  std::set<std::string> visited_;
  int moves_spent_ = 0;
  bool timeout_fired_ = false;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_CHAPTER_H_
