// Reader for the JavaScript content files.
//
// Every file under content/ has the shape
//
//   Tenebris.content.<name> = <literal>;
//
// where <literal> is a JavaScript object, array or scalar. The parser
// accepts the readable subset of the language used by the content: line and
// block comments, unquoted object keys, single or double quoted strings and
// trailing commas. No code is executed, so content files stay pure data.

#ifndef TENEBRIS_SRC_JS_PARSER_H_
#define TENEBRIS_SRC_JS_PARSER_H_

#include <string>

#include "src/js_value.h"

namespace tenebris {
namespace js_parser {

// Parses an assignment held in `source`. `file_name` only decorates error
// messages. Returns false and fills *error when the input is malformed.
bool ParseAssignment(const std::string& source, const std::string& file_name,
                     JsValue* out, std::string* error);

// Reads `path` and parses its assignment.
bool ParseFile(const std::string& path, JsValue* out, std::string* error);

}  // namespace js_parser
}  // namespace tenebris

#endif  // TENEBRIS_SRC_JS_PARSER_H_
