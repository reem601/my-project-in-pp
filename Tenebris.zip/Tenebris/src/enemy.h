// Shadow creatures the heroine fights, described in content/enemies.js.

#ifndef TENEBRIS_SRC_ENEMY_H_
#define TENEBRIS_SRC_ENEMY_H_

#include <string>
#include <vector>

#include "src/js_value.h"

namespace tenebris {

class Player;

// One entry of an enemy's move table.
struct EnemyAttack {
  std::string name;
  std::string text;
  int hp_damage = 0;
  int mental_damage = 0;
  int blocked_turns = 0;
  int weight = 1;
};

// What a single enemy turn did, so that the combat system can narrate it.
struct AttackOutcome {
  std::string text;
  int hp_lost = 0;
  int mental_lost = 0;
  int blocked_turns = 0;
  int healed = 0;
  bool evaded = false;
};

class Enemy {
 public:
  explicit Enemy(const JsValue& def);
  virtual ~Enemy() = default;

  Enemy(const Enemy&) = delete;
  Enemy& operator=(const Enemy&) = delete;

  const std::string& id() const { return id_; }
  const std::string& name() const { return name_; }
  const std::string& intro() const { return intro_; }
  const std::string& defeat_text() const { return defeat_text_; }
  int hp() const { return hp_; }
  int max_hp() const { return max_hp_; }
  bool alive() const { return hp_ > 0; }
  bool is_boss() const { return is_boss_; }

  void TakeDamage(int amount);
  void Heal(int amount);

  // Plays one enemy turn against `player`. When `evaded` is true the move is
  // announced but lands no effect.
  virtual AttackOutcome Attack(Player* player, bool evaded);

 protected:
  // Weighted pick from the move table; never returns null for a valid enemy.
  const EnemyAttack* ChooseAttack() const;

  // Applies `attack` to `player` and fills the outcome.
  AttackOutcome Apply(const EnemyAttack& attack, Player* player, bool evaded);

  std::string id_;
  std::string name_;
  std::string intro_;
  std::string defeat_text_;
  int hp_ = 1;
  int max_hp_ = 1;
  bool is_boss_ = false;
  std::vector<EnemyAttack> attacks_;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_ENEMY_H_
