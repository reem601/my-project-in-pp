// Глава 6. Испытание решимости.
// Единственная глава с лимитом ходов: move_limit считает пройденные узлы,
// после чего управление уходит в timeout_node.

Tenebris.content.chapter_6 = {
  id: "chapter_6",
  title: "Глава 6. Испытание решимости",
  start: "bridge_start",
  move_limit: 6,
  timeout_node: "bridge_fall",
  death_ending: "bad",

  intro: [
    "Из Башни есть только один выход наверх — мост между мирами.",
    "Он существует ровно столько, сколько на него смотрят."
  ],

  nodes: [
    {
      id: "bridge_start",
      text: [
        "Мост уходит в темноту без опор и перил. Доски под ногами гаснут",
        "одна за другой, догорая, как спички."
      ],
      revisit_text: ["Начало моста. Досок позади заметно меньше."],
      choices: [
        {
          text: "Идти быстро, не глядя вниз",
          effects: {
            mental: -5,
            text: ["Вы почти бежите. Мост не успевает придумать вам ловушку."]
          },
          next: "bridge_middle"
        },
        {
          text: "Идти осторожно, проверяя каждую доску",
          effects: {
            text: ["Каждый шаг занимает время, которого у моста нет."]
          },
          next: "bridge_slow"
        },
        {
          text: "Осмотреться по сторонам",
          next: "bridge_look"
        }
      ]
    },

    {
      id: "bridge_look",
      text: [
        "Внизу — не пропасть, а комната. Ваша комната в Люмерии, вид",
        "сверху. На столе горит свеча, которую вы точно потушили."
      ],
      on_enter: {
        mental: -8
      },
      next: "bridge_start"
    },

    {
      id: "bridge_slow",
      text: [
        "На середине пролёта доска под каблуком оказывается нарисованной.",
        "Вы успеваете перенести вес."
      ],
      on_enter: {
        hp: -5
      },
      next: "bridge_middle"
    },

    {
      id: "bridge_middle",
      text: [
        "Мост упирается в фонарь, висящий в пустоте."
      ],
      next: "bridge_puzzle"
    },

    {
      id: "bridge_puzzle",
      type: "puzzle",
      puzzle: "bridge_riddle",
      on_solve: "bridge_far",
      on_fail: "bridge_fall"
    },

    {
      id: "bridge_far",
      text: [
        "Дальний край моста упирается в дверь, стоящую без стены.",
        "Вы оборачиваетесь: моста за спиной уже нет."
      ],
      on_enter: {
        mental: 10
      },
      next: "before_the_door"
    },

    {
      id: "bridge_fall",
      text: [
        "Опора уходит. Вы падаете и в последний момент цепляетесь",
        "за край чего-то твёрдого."
      ],
      on_enter: {
        hp: -15,
        set: ["bridge_failed"]
      },
      choices: [
        {
          text: "Подтянуться, пока пальцы держат",
          require_mental: 20,
          locked_text: "Страх сильнее. Руки не слушаются.",
          next: "bridge_climb"
        },
        {
          text: "Позвать Элиана по имени",
          forbid_flags: ["called_the_name"],
          hidden: true,
          effects: {
            set: ["called_the_name"],
            mental: 15,
            text: [
              "Вы кричите его имя в пустоту. Пустота отвечает эхом,",
              "и в этом эхе слышно чужое дыхание. Хватка становится крепче."
            ]
          },
          next: "bridge_fall"
        },
        {
          text: "Отпустить",
          effects: {
            set: ["gave_up"],
            text: ["Вы разжимаете пальцы. Падение оказывается тихим."]
          },
          ending: "bad"
        }
      ]
    },

    {
      id: "bridge_climb",
      text: [
        "Вы вытаскиваете себя на плиту, которой пять секунд назад не было.",
        "Дверь без стены стоит в трёх шагах."
      ],
      on_enter: {
        hp: -5
      },
      next: "before_the_door"
    },

    {
      id: "before_the_door",
      text: [
        "У самой двери лежит ваш дорожный мешок — снова, хотя вы точно",
        "оставили его в Башне. Мир теней насмешлив, но не мелочен.",
        "",
        "Вы садитесь на порог и позволяете себе одну минуту."
      ],
      on_enter: {
        give: ["apple", "crystal"],
        mental: 5
      },
      next: "chapter_6_end"
    },

    {
      id: "chapter_6_end",
      type: "chapter_end"
    }
  ]
};
