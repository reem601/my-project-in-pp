// Single source of randomness for combat rolls and enemy behaviour.

#ifndef TENEBRIS_SRC_RNG_H_
#define TENEBRIS_SRC_RNG_H_

namespace tenebris {
namespace rng {

// Seeds the generator; called once at start-up.
void Seed(unsigned int seed);

// Uniform value in the inclusive range [low, high].
int Range(int low, int high);

// True with the given probability expressed in percent.
bool Chance(int percent);

}  // namespace rng
}  // namespace tenebris

#endif  // TENEBRIS_SRC_RNG_H_
