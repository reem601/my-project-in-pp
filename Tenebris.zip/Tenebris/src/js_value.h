// Dynamic value tree that mirrors the data declared in the JavaScript
// content files.

#ifndef TENEBRIS_SRC_JS_VALUE_H_
#define TENEBRIS_SRC_JS_VALUE_H_

#include <cstddef>
#include <string>
#include <utility>
#include <vector>

namespace tenebris {

// Object members keep their declaration order so that content files stay
// readable and diffable.
class JsValue {
 public:
  enum class Type { kNull, kBool, kNumber, kString, kArray, kObject };

  JsValue() = default;

  static JsValue Bool(bool value);
  static JsValue Number(double value);
  static JsValue String(std::string value);
  static JsValue Array();
  static JsValue Object();

  // Shared empty value returned by failed lookups.
  static const JsValue& Null();

  Type type() const { return type_; }
  bool is_null() const { return type_ == Type::kNull; }
  bool is_string() const { return type_ == Type::kString; }
  bool is_array() const { return type_ == Type::kArray; }
  bool is_object() const { return type_ == Type::kObject; }

  bool AsBool(bool fallback = false) const;
  double AsNumber(double fallback = 0.0) const;
  int AsInt(int fallback = 0) const;
  std::string AsString(const std::string& fallback = std::string()) const;

  // Collects the elements of a string array; a bare string is treated as a
  // one element array, which keeps short content entries terse.
  std::vector<std::string> AsStringList() const;

  std::size_t size() const;
  const JsValue& At(std::size_t index) const;
  const JsValue& Get(const std::string& key) const;
  bool Has(const std::string& key) const;

  const std::vector<JsValue>& elements() const { return elements_; }

  void Append(JsValue value);
  void Set(std::string key, JsValue value);

 private:
  Type type_ = Type::kNull;
  bool bool_value_ = false;
  double number_value_ = 0.0;
  std::string string_value_;
  std::vector<JsValue> elements_;
  std::vector<std::pair<std::string, JsValue>> members_;
};

// Finds the entry of `array` whose "id" member equals `id`.
const JsValue& FindById(const JsValue& array, const std::string& id);

}  // namespace tenebris

#endif  // TENEBRIS_SRC_JS_VALUE_H_
