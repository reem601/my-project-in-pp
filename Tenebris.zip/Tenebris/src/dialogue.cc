#include "src/dialogue.h"

#include <cctype>
#include <cstddef>
#include <string>
#include <vector>

#include "src/console.h"
#include "src/content_database.h"
#include "src/item.h"
#include "src/js_value.h"
#include "src/player.h"
#include "src/text_util.h"

namespace tenebris {
namespace {

// Splits `input` into its first word and the remainder.
void SplitCommand(const std::string& input, std::string* head,
                  std::string* tail) {
  const std::string trimmed = text_util::Trim(input);
  const std::size_t space = trimmed.find(' ');
  if (space == std::string::npos) {
    *head = trimmed;
    tail->clear();
    return;
  }
  *head = trimmed.substr(0, space);
  *tail = text_util::Trim(trimmed.substr(space + 1));
}

bool ParseIndex(const std::string& text, int* value) {
  if (text.empty()) return false;
  int result = 0;
  for (char digit : text) {
    if (std::isdigit(static_cast<unsigned char>(digit)) == 0) return false;
    result = result * 10 + (digit - '0');
  }
  *value = result;
  return true;
}

}  // namespace

void Dialogue::ShowText(const std::vector<std::string>& lines) const {
  for (const std::string& line : lines) {
    console::Print(line);
  }
}

void Dialogue::ShowLine(const std::string& line) const { console::Print(line); }

void Dialogue::ShowTitle(const std::string& title) const {
  console::PrintBlank();
  console::PrintRule();
  console::PrintRaw(title);
  console::PrintRule();
  console::PrintBlank();
}

void Dialogue::ShowUi(const std::string& key) const {
  console::Print(content_->Text(key));
}

void Dialogue::ShowUi(const std::string& key,
                      const std::vector<std::string>& args) const {
  console::Print(content_->Text(key, args));
}

void Dialogue::ShowStatus(const Player& player) const {
  console::PrintBlank();
  console::PrintRaw(content_->Text("status_title"));
  console::PrintGauge(content_->Text("status_hp_label"), player.hp(),
                      Player::kMaxHp);
  console::PrintGauge(content_->Text("status_mental_label"),
                      player.mental_state(), Player::kMaxMental);
  console::Print(content_->Text(player.fragile() ? "status_state_fragile"
                                                 : "status_state_calm"));
  console::PrintBlank();
}

void Dialogue::ShowInventory(const Player& player) const {
  console::PrintBlank();
  console::PrintRaw(content_->Text("inventory_title"));
  const std::vector<Item>& items = player.inventory().items();
  if (items.empty()) {
    console::Print(content_->Text("inventory_empty"));
    console::PrintBlank();
    return;
  }
  for (std::size_t i = 0; i < items.size(); ++i) {
    console::Print(content_->Text("inventory_line",
                                  {text_util::FromInt(static_cast<int>(i) + 1),
                                   items[i].name(), items[i].description()}));
  }
  console::PrintBlank();
}

void Dialogue::ShowHelp() const {
  console::PrintBlank();
  const std::vector<std::string> lines = content_->TextList("help");
  for (const std::string& line : lines) {
    console::Print(line);
  }
  console::PrintBlank();
}

bool Dialogue::IsCommand(const std::string& word,
                         const std::string& command) const {
  const JsValue& aliases = content_->ui().Get("commands").Get(command);
  for (const JsValue& alias : aliases.elements()) {
    if (text_util::Normalize(alias.AsString()) == word) return true;
  }
  return false;
}

bool Dialogue::UseItemByToken(const std::string& token, Player* player) const {
  const std::vector<Item>& items = player->inventory().items();
  const std::string needle = text_util::Normalize(token);
  std::string target_id;
  int index = 0;
  if (ParseIndex(token, &index) && index >= 1 &&
      static_cast<std::size_t>(index) <= items.size()) {
    target_id = items[index - 1].id();
  } else {
    for (const Item& item : items) {
      if (text_util::Normalize(item.name()).find(needle) != std::string::npos) {
        target_id = item.id();
        break;
      }
    }
  }
  if (target_id.empty()) {
    ShowUi("item_use_unknown");
    return false;
  }
  const Item* const target = player->inventory().Find(target_id);
  if (target == nullptr || !target->usable()) {
    ShowUi("item_use_not_usable");
    return false;
  }
  if (!target->HasEffectOn(*player)) {
    ShowUi("item_use_no_effect");
    return false;
  }
  std::string message;
  if (!player->inventory().UseItem(target_id, player, &message)) {
    ShowUi("item_use_not_usable");
    return false;
  }
  console::Print(message);
  return true;
}

bool Dialogue::UseItemInteractive(Player* player) {
  bool has_usable = false;
  for (const Item& item : player->inventory().items()) {
    if (item.usable() && item.HasEffectOn(*player)) has_usable = true;
  }
  if (!has_usable) {
    ShowUi("item_none_usable");
    return false;
  }
  ShowInventory(*player);
  std::string answer;
  if (!AskAnswer(content_->Text("item_use_prompt"), player, &answer)) {
    return false;
  }
  return UseItemByToken(answer, player);
}

bool Dialogue::HandleServiceCommand(const std::string& input, Player* player) {
  std::string head;
  std::string tail;
  SplitCommand(input, &head, &tail);
  head = text_util::Normalize(head);
  if (head.empty()) return true;

  if (IsCommand(head, "help")) {
    ShowHelp();
    return true;
  }
  if (IsCommand(head, "status")) {
    ShowStatus(*player);
    return true;
  }
  if (IsCommand(head, "inventory")) {
    ShowInventory(*player);
    return true;
  }
  if (IsCommand(head, "use")) {
    if (tail.empty()) {
      ShowInventory(*player);
      ShowUi("item_use_prompt");
    } else {
      UseItemByToken(tail, player);
    }
    return true;
  }
  if (IsCommand(head, "quit")) {
    quit_requested_ = true;
    return true;
  }
  return false;
}

int Dialogue::PresentChoices(const std::vector<ChoiceOption>& options,
                             Player* player) {
  while (true) {
    console::PrintBlank();
    for (std::size_t i = 0; i < options.size(); ++i) {
      const std::string number = text_util::FromInt(static_cast<int>(i) + 1);
      const std::string key =
          options[i].enabled ? "choice_line" : "choice_locked_line";
      console::Print(content_->Text(key, {number, options[i].text}));
    }
    console::PrintRaw(content_->Text("prompt_choice"));

    std::string input;
    if (!console::ReadLine(&input)) {
      quit_requested_ = true;
      return kQuitRequested;
    }
    int index = 0;
    if (ParseIndex(text_util::Trim(input), &index) && index >= 1 &&
        static_cast<std::size_t>(index) <= options.size()) {
      const ChoiceOption& option = options[index - 1];
      if (option.enabled) return index - 1;
      console::Print(option.locked_text.empty()
                         ? content_->Text("choice_locked_default")
                         : option.locked_text);
      continue;
    }
    if (HandleServiceCommand(input, player)) {
      if (quit_requested_) return kQuitRequested;
      continue;
    }
    ShowUi("unknown_command");
  }
}

bool Dialogue::AskAnswer(const std::string& prompt, Player* player,
                         std::string* answer) {
  while (true) {
    console::PrintBlank();
    console::PrintRaw(prompt);
    std::string input;
    if (!console::ReadLine(&input)) {
      quit_requested_ = true;
      return false;
    }
    const std::string trimmed = text_util::Trim(input);
    if (trimmed.empty()) continue;
    if (HandleServiceCommand(trimmed, player)) {
      if (quit_requested_) return false;
      continue;
    }
    *answer = trimmed;
    return true;
  }
}

}  // namespace tenebris
