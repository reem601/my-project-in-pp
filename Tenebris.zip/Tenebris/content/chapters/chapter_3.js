// Глава 3. Память прошлого.
// Мир теней питается страхами: локации собраны из воспоминаний героини.

Tenebris.content.chapter_3 = {
  id: "chapter_3",
  title: "Глава 3. Память прошлого",
  start: "memory_hall",

  intro: [
    "Дорога от перекрёстка приводит в коридор с дверями по обе стороны.",
    "За каждой — год вашей жизни. Некоторые двери заколочены изнутри."
  ],

  nodes: [
    {
      id: "memory_hall",
      text: [
        "Одна дверь отличается: на ней вашим детским почерком написано",
        "«не входить». Дальше по коридору коридор кончается зеркалом."
      ],
      revisit_text: ["Коридор памяти. Зеркало в конце ждёт."],
      choices: [
        {
          text: "Открыть дверь с надписью",
          forbid_flags: ["faced_memory", "avoided_memory"],
          hidden: true,
          next: "memory_puzzle"
        },
        {
          text: "Пройти мимо, к зеркалу",
          forbid_flags: ["faced_memory"],
          hidden: true,
          effects: {
            set: ["avoided_memory"],
            mental: -12,
            text: [
              "Вы проходите мимо. Дверь тихо повторяет за вами каждый шаг."
            ]
          },
          next: "mirror_room"
        },
        {
          text: "Подойти к зеркалу",
          require_flags: ["faced_memory"],
          hidden: true,
          next: "mirror_room"
        }
      ]
    },

    {
      id: "memory_puzzle",
      type: "puzzle",
      puzzle: "memory_riddle",
      on_solve: "memory_hall",
      on_fail: "memory_hall",
      on_fail_effects: {
        set: ["avoided_memory"]
      }
    },

    {
      id: "mirror_room",
      text: [
        "Зеркало не отражает — оно выпускает.",
        "Из него выходите вы, только младше и злее."
      ],
      type: "combat",
      enemy: "reflection",
      on_win: "after_mirror",
      on_win_effects: {
        mental: 12,
        text: ["Осколки складываются в лицо, которое вы узнаёте. Своё."]
      },
      on_lose: "after_mirror",
      on_lose_effects: {
        mental: -8,
        text: ["Отражение отпускает вас, потеряв интерес. Это унизительно."]
      },
      revive_hp: 25,
      revive_mental: 20
    },

    {
      id: "after_mirror",
      text: [
        "За рамой зеркала — лестница вниз и запах сырой листвы.",
        "Вы начинаете понимать: этот мир кормится тем, чего вы боитесь.",
        "Значит, у него есть аппетит. Значит, его можно оставить голодным."
      ],
      on_enter: {
        give: ["apple"],
        set: ["understood_world"]
      },
      next: "chapter_3_end"
    },

    {
      id: "chapter_3_end",
      type: "chapter_end"
    }
  ]
};
