#include "src/text_util.h"

#include <cctype>
#include <cstddef>
#include <string>
#include <vector>

namespace tenebris {
namespace text_util {
namespace {

constexpr unsigned char kContinuationMask = 0xC0;
constexpr unsigned char kContinuationTag = 0x80;

bool IsContinuation(char byte) {
  return (static_cast<unsigned char>(byte) & kContinuationMask) ==
         kContinuationTag;
}

// Cyrillic capitals occupy U+0410..U+042F, encoded as 0xD0 0x90..0xD0 0xAF.
// The lower case half starts at U+0430, which crosses the 0xD0/0xD1 lead
// byte boundary in the middle of the block.
void LowerCyrillicPair(unsigned char lead, unsigned char trail,
                       std::string* out) {
  if (lead == 0xD0 && trail >= 0x90 && trail <= 0x9F) {
    out->push_back(static_cast<char>(0xD0));
    out->push_back(static_cast<char>(trail + 0x20));
    return;
  }
  if (lead == 0xD0 && trail >= 0xA0 && trail <= 0xAF) {
    out->push_back(static_cast<char>(0xD1));
    out->push_back(static_cast<char>(trail - 0x20));
    return;
  }
  out->push_back(static_cast<char>(lead));
  out->push_back(static_cast<char>(trail));
}

}  // namespace

std::string Trim(const std::string& text) {
  std::size_t begin = 0;
  std::size_t end = text.size();
  while (begin < end &&
         std::isspace(static_cast<unsigned char>(text[begin])) != 0) {
    ++begin;
  }
  while (end > begin &&
         std::isspace(static_cast<unsigned char>(text[end - 1])) != 0) {
    --end;
  }
  return text.substr(begin, end - begin);
}

std::string Normalize(const std::string& text) {
  std::string result;
  result.reserve(text.size());
  for (std::size_t i = 0; i < text.size(); ++i) {
    const unsigned char lead = static_cast<unsigned char>(text[i]);
    if (lead < 0x80) {
      result.push_back(
          static_cast<char>(std::tolower(static_cast<unsigned char>(text[i]))));
      continue;
    }
    if ((lead == 0xD0 || lead == 0xD1) && i + 1 < text.size()) {
      const unsigned char trail = static_cast<unsigned char>(text[i + 1]);
      // "Ё" (0xD0 0x81) and "ё" (0xD1 0x91) both fold into "е".
      if ((lead == 0xD0 && trail == 0x81) || (lead == 0xD1 && trail == 0x91)) {
        result.push_back(static_cast<char>(0xD0));
        result.push_back(static_cast<char>(0xB5));
      } else {
        LowerCyrillicPair(lead, trail, &result);
      }
      ++i;
      continue;
    }
    result.push_back(text[i]);
  }
  return result;
}

std::size_t GlyphCount(const std::string& text) {
  std::size_t count = 0;
  for (char byte : text) {
    if (!IsContinuation(byte)) ++count;
  }
  return count;
}

std::vector<std::string> Wrap(const std::string& text, std::size_t width) {
  std::vector<std::string> lines;
  if (width == 0) {
    lines.push_back(text);
    return lines;
  }
  // Leading spaces are indentation of a pre-formatted line (menus, lists);
  // they are kept on every produced line instead of being collapsed.
  std::size_t indent_size = 0;
  while (indent_size < text.size() && text[indent_size] == ' ') ++indent_size;
  if (indent_size == text.size()) {
    lines.push_back(text);
    return lines;
  }
  if (indent_size + 8 < width) width -= indent_size;
  const std::string indent(indent_size, ' ');

  std::string line;
  std::string word;
  std::size_t line_width = 0;
  std::size_t word_width = 0;
  auto flush_word = [&]() {
    if (word.empty()) return;
    if (line_width != 0 && line_width + 1 + word_width > width) {
      lines.push_back(indent + line);
      line.clear();
      line_width = 0;
    }
    if (line_width != 0) {
      line.push_back(' ');
      ++line_width;
    }
    line += word;
    line_width += word_width;
    word.clear();
    word_width = 0;
  };

  for (char byte : text) {
    if (byte == ' ' || byte == '\t') {
      flush_word();
      continue;
    }
    word.push_back(byte);
    if (!IsContinuation(byte)) ++word_width;
  }
  flush_word();
  if (!line.empty() || lines.empty()) lines.push_back(indent + line);
  return lines;
}

std::string ReplaceAll(const std::string& text, const std::string& from,
                       const std::string& to) {
  if (from.empty()) return text;
  std::string result;
  std::size_t pos = 0;
  while (true) {
    const std::size_t hit = text.find(from, pos);
    if (hit == std::string::npos) {
      result += text.substr(pos);
      return result;
    }
    result += text.substr(pos, hit - pos);
    result += to;
    pos = hit + from.size();
  }
}

std::string Format(const std::string& pattern,
                   const std::vector<std::string>& args) {
  std::string result = pattern;
  for (std::size_t i = 0; i < args.size(); ++i) {
    result =
        ReplaceAll(result, "{" + FromInt(static_cast<int>(i)) + "}", args[i]);
  }
  return result;
}

std::string FromInt(int value) {
  if (value == 0) return "0";
  const bool negative = value < 0;
  // Negate in the unsigned domain so that the smallest int still converts.
  unsigned int rest = negative ? 0u - static_cast<unsigned int>(value)
                               : static_cast<unsigned int>(value);
  std::string digits;
  while (rest > 0) {
    digits.push_back(static_cast<char>('0' + rest % 10));
    rest /= 10;
  }
  if (negative) digits.push_back('-');
  return std::string(digits.rbegin(), digits.rend());
}

}  // namespace text_util
}  // namespace tenebris
