#include "src/enemy.h"

#include <string>
#include <vector>

#include "src/js_value.h"
#include "src/player.h"
#include "src/rng.h"

namespace tenebris {

Enemy::Enemy(const JsValue& def) {
  id_ = def.Get("id").AsString();
  name_ = def.Get("name").AsString(id_);
  intro_ = def.Get("intro").AsString();
  defeat_text_ = def.Get("defeat_text").AsString();
  max_hp_ = def.Get("hp").AsInt(60);
  if (max_hp_ < 1) max_hp_ = 1;
  hp_ = max_hp_;
  is_boss_ = def.Get("boss").AsBool(false);
  for (const JsValue& entry : def.Get("attacks").elements()) {
    EnemyAttack attack;
    attack.name = entry.Get("name").AsString();
    attack.text = entry.Get("text").AsString(attack.name);
    attack.hp_damage = entry.Get("hp_damage").AsInt(0);
    attack.mental_damage = entry.Get("mental_damage").AsInt(0);
    attack.blocked_turns = entry.Get("blocked_turns").AsInt(0);
    attack.weight = entry.Get("weight").AsInt(1);
    if (attack.weight < 1) attack.weight = 1;
    attacks_.push_back(attack);
  }
}

void Enemy::TakeDamage(int amount) {
  if (amount < 0) amount = 0;
  hp_ -= amount;
  if (hp_ < 0) hp_ = 0;
}

void Enemy::Heal(int amount) {
  hp_ += amount;
  if (hp_ > max_hp_) hp_ = max_hp_;
}

const EnemyAttack* Enemy::ChooseAttack() const {
  if (attacks_.empty()) return nullptr;
  int total = 0;
  for (const EnemyAttack& attack : attacks_) total += attack.weight;
  int roll = rng::Range(1, total);
  for (const EnemyAttack& attack : attacks_) {
    roll -= attack.weight;
    if (roll <= 0) return &attack;
  }
  return &attacks_.back();
}

AttackOutcome Enemy::Apply(const EnemyAttack& attack, Player* player,
                           bool evaded) {
  AttackOutcome outcome;
  outcome.text = attack.text;
  if (evaded) {
    outcome.evaded = true;
    player->ClearGuard();
    return outcome;
  }
  const int mental_before = player->mental_state();
  outcome.hp_lost = player->TakeDamage(attack.hp_damage, attack.mental_damage);
  outcome.mental_lost = mental_before - player->mental_state();
  outcome.blocked_turns = attack.blocked_turns;
  return outcome;
}

AttackOutcome Enemy::Attack(Player* player, bool evaded) {
  const EnemyAttack* attack = ChooseAttack();
  if (attack == nullptr) return AttackOutcome();
  return Apply(*attack, player, evaded);
}

}  // namespace tenebris
