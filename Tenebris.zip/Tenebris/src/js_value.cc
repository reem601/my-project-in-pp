#include "src/js_value.h"

#include <cstddef>
#include <string>
#include <utility>
#include <vector>

namespace tenebris {

JsValue JsValue::Bool(bool value) {
  JsValue result;
  result.type_ = Type::kBool;
  result.bool_value_ = value;
  return result;
}

JsValue JsValue::Number(double value) {
  JsValue result;
  result.type_ = Type::kNumber;
  result.number_value_ = value;
  return result;
}

JsValue JsValue::String(std::string value) {
  JsValue result;
  result.type_ = Type::kString;
  result.string_value_ = std::move(value);
  return result;
}

JsValue JsValue::Array() {
  JsValue result;
  result.type_ = Type::kArray;
  return result;
}

JsValue JsValue::Object() {
  JsValue result;
  result.type_ = Type::kObject;
  return result;
}

const JsValue& JsValue::Null() {
  static const JsValue* const kNullValue = new JsValue();
  return *kNullValue;
}

bool JsValue::AsBool(bool fallback) const {
  switch (type_) {
    case Type::kBool:
      return bool_value_;
    case Type::kNumber:
      return number_value_ != 0.0;
    case Type::kNull:
      return fallback;
    default:
      return true;
  }
}

double JsValue::AsNumber(double fallback) const {
  return type_ == Type::kNumber ? number_value_ : fallback;
}

int JsValue::AsInt(int fallback) const {
  if (type_ != Type::kNumber) return fallback;
  return static_cast<int>(number_value_ < 0 ? number_value_ - 0.5
                                            : number_value_ + 0.5);
}

std::string JsValue::AsString(const std::string& fallback) const {
  return type_ == Type::kString ? string_value_ : fallback;
}

std::vector<std::string> JsValue::AsStringList() const {
  std::vector<std::string> result;
  if (type_ == Type::kString) {
    result.push_back(string_value_);
    return result;
  }
  if (type_ != Type::kArray) return result;
  for (const JsValue& element : elements_) {
    result.push_back(element.AsString());
  }
  return result;
}

std::size_t JsValue::size() const {
  if (type_ == Type::kArray) return elements_.size();
  if (type_ == Type::kObject) return members_.size();
  return 0;
}

const JsValue& JsValue::At(std::size_t index) const {
  if (type_ != Type::kArray || index >= elements_.size()) return Null();
  return elements_[index];
}

const JsValue& JsValue::Get(const std::string& key) const {
  if (type_ != Type::kObject) return Null();
  for (const std::pair<std::string, JsValue>& member : members_) {
    if (member.first == key) return member.second;
  }
  return Null();
}

bool JsValue::Has(const std::string& key) const { return !Get(key).is_null(); }

void JsValue::Append(JsValue value) {
  type_ = Type::kArray;
  elements_.push_back(std::move(value));
}

void JsValue::Set(std::string key, JsValue value) {
  type_ = Type::kObject;
  for (std::pair<std::string, JsValue>& member : members_) {
    if (member.first == key) {
      member.second = std::move(value);
      return;
    }
  }
  members_.emplace_back(std::move(key), std::move(value));
}

const JsValue& FindById(const JsValue& array, const std::string& id) {
  for (const JsValue& element : array.elements()) {
    if (element.Get("id").AsString() == id) return element;
  }
  return JsValue::Null();
}

}  // namespace tenebris
