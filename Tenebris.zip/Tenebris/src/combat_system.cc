#include "src/combat_system.h"

#include <cstddef>
#include <string>
#include <vector>

#include "src/console.h"
#include "src/content_database.h"
#include "src/dialogue.h"
#include "src/enemy.h"
#include "src/player.h"
#include "src/rng.h"
#include "src/text_util.h"

namespace tenebris {
namespace {

// Tuning constants for the heroine's moves, taken from the design document.
constexpr int kShadowPowerHeal = 15;
constexpr int kShadowPowerDamage = 12;
constexpr int kShadowPowerMentalCost = 5;
constexpr int kSkipTurnHeal = 5;
constexpr int kShadowStrikeDamage = 10;
constexpr int kWillpowerMentalGain = 15;
constexpr int kWillpowerHpCost = 5;
constexpr int kLightShieldHeal = 10;
constexpr int kHiddenAttackDamage = 20;

}  // namespace

void CombatSystem::ShowGauges(const Player& player, const Enemy& enemy) const {
  console::PrintBlank();
  console::PrintGauge(content_->Text("status_hp_label"), player.hp(),
                      Player::kMaxHp);
  console::PrintGauge(content_->Text("status_mental_label"),
                      player.mental_state(), Player::kMaxMental);
  console::PrintGauge(enemy.name(), enemy.hp(), enemy.max_hp());
}

void CombatSystem::ApplyPlayerDamage(int damage, Enemy* enemy) {
  enemy->TakeDamage(damage);
  dialogue_->ShowUi("combat_player_hit",
                    {enemy->name(), text_util::FromInt(damage)});
}

bool CombatSystem::PlayerTurn(Player* player, Enemy* enemy) {
  while (true) {
    std::vector<Move> moves;
    std::vector<ChoiceOption> options;
    const bool sealed = sealed_turns_ > 0;

    auto add = [&](Move move, const char* key, bool enabled) {
      moves.push_back(move);
      ChoiceOption option;
      option.text = content_->Text(key);
      option.enabled = enabled;
      option.locked_text = content_->Text("combat_move_sealed");
      options.push_back(option);
    };

    if (enemy->is_boss()) {
      add(Move::kShadowStrike, "move_strike", true);
      add(Move::kLightShield, "move_shield", true);
      add(Move::kDodge, "move_dodge", true);
      add(Move::kWillpower, "move_willpower", true);
      add(Move::kSkipTurn, "move_skip", true);
      add(Move::kHiddenAttack, "move_hidden", hidden_ready_ && !sealed);
    } else {
      add(Move::kAttack, "move_attack", true);
      add(Move::kDefend, "move_defend", true);
      add(Move::kDodge, "move_dodge", true);
      add(Move::kShadowPower, "move_power", !sealed);
    }
    add(Move::kUseItem, "move_item", true);

    const int index = dialogue_->PresentChoices(options, player);
    if (index == Dialogue::kQuitRequested) return false;

    const Move move = moves[static_cast<std::size_t>(index)];
    bool turn_spent = true;
    switch (move) {
      case Move::kAttack:
        ApplyPlayerDamage(player->Attack(), enemy);
        break;
      case Move::kDefend:
        player->Defend();
        dialogue_->ShowUi("combat_defend");
        break;
      case Move::kDodge:
        dodging_ = true;
        dialogue_->ShowUi("combat_dodge_ready");
        break;
      case Move::kShadowPower:
        player->ChangeMental(-kShadowPowerMentalCost);
        if (rng::Chance(50)) {
          player->ChangeHp(kShadowPowerHeal);
          dialogue_->ShowUi("combat_power_heal",
                            {text_util::FromInt(kShadowPowerHeal)});
        } else {
          ApplyPlayerDamage(kShadowPowerDamage, enemy);
          dialogue_->ShowUi("combat_power_damage");
        }
        break;
      case Move::kSkipTurn:
        player->ChangeHp(kSkipTurnHeal);
        hidden_ready_ = true;
        dialogue_->ShowUi("combat_skip", {text_util::FromInt(kSkipTurnHeal)});
        break;
      case Move::kShadowStrike:
        ApplyPlayerDamage(kShadowStrikeDamage, enemy);
        break;
      case Move::kWillpower:
        player->ChangeMental(kWillpowerMentalGain);
        player->ChangeHp(-kWillpowerHpCost);
        dialogue_->ShowUi("combat_willpower",
                          {text_util::FromInt(kWillpowerMentalGain),
                           text_util::FromInt(kWillpowerHpCost)});
        break;
      case Move::kLightShield:
        shielded_ = true;
        player->ChangeHp(kLightShieldHeal);
        dialogue_->ShowUi("combat_shield",
                          {text_util::FromInt(kLightShieldHeal)});
        break;
      case Move::kHiddenAttack:
        ApplyPlayerDamage(kHiddenAttackDamage, enemy);
        dialogue_->ShowUi("combat_hidden");
        break;
      case Move::kUseItem:
        turn_spent = dialogue_->UseItemInteractive(player);
        if (dialogue_->quit_requested()) return false;
        break;
    }

    if (!turn_spent) continue;
    // Only a skipped turn leaves the heroine coiled for the hidden strike.
    if (move != Move::kSkipTurn) hidden_ready_ = false;
    if (sealed_turns_ > 0) --sealed_turns_;
    return true;
  }
}

void CombatSystem::EnemyTurn(Player* player, Enemy* enemy) {
  if (shielded_) {
    shielded_ = false;
    dodging_ = false;
    player->ClearGuard();
    dialogue_->ShowUi("combat_shield_blocked", {enemy->name()});
    return;
  }
  const bool evaded = dodging_ && player->Dodge();
  dodging_ = false;

  const AttackOutcome outcome = enemy->Attack(player, evaded);
  if (!outcome.text.empty()) dialogue_->ShowLine(outcome.text);
  if (outcome.evaded) {
    dialogue_->ShowUi("combat_evaded");
    return;
  }
  if (outcome.hp_lost > 0) {
    dialogue_->ShowUi("combat_hp_lost", {text_util::FromInt(outcome.hp_lost)});
  }
  if (outcome.mental_lost > 0) {
    dialogue_->ShowUi("combat_mental_lost",
                      {text_util::FromInt(outcome.mental_lost)});
  }
  if (outcome.healed > 0) {
    dialogue_->ShowUi("combat_enemy_healed",
                      {enemy->name(), text_util::FromInt(outcome.healed)});
  }
  if (outcome.blocked_turns > 0) {
    sealed_turns_ += outcome.blocked_turns;
    dialogue_->ShowUi("combat_sealed",
                      {text_util::FromInt(outcome.blocked_turns)});
  }
}

BattleResult CombatSystem::StartBattle(Player* player, Enemy* enemy) {
  sealed_turns_ = 0;
  dodging_ = false;
  hidden_ready_ = false;
  shielded_ = false;

  dialogue_->ShowTitle(content_->Text("combat_title", {enemy->name()}));
  if (!enemy->intro().empty()) dialogue_->ShowLine(enemy->intro());

  while (true) {
    ShowGauges(*player, *enemy);
    if (!PlayerTurn(player, enemy)) return BattleResult::kQuit;

    if (!enemy->alive()) {
      if (!enemy->defeat_text().empty()) {
        dialogue_->ShowLine(enemy->defeat_text());
      }
      dialogue_->ShowUi("combat_victory", {enemy->name()});
      player->SetFlag("defeated_" + enemy->id());
      return BattleResult::kVictory;
    }

    EnemyTurn(player, enemy);

    if (!player->alive()) {
      dialogue_->ShowUi("combat_defeat");
      return BattleResult::kDefeat;
    }
    if (player->broken()) {
      dialogue_->ShowUi("combat_mind_broken");
      player->SetFlag("mind_broken");
      return BattleResult::kDefeat;
    }
  }
}

}  // namespace tenebris
