// Манифест контента: список файлов, которые движок загружает при старте.
// Порядок глав в массиве chapters задаёт порядок прохождения игры.

Tenebris.content.index = {
  ui: "ui.js",
  items: "items.js",
  enemies: "enemies.js",
  puzzles: "puzzles.js",
  endings: "endings.js",
  chapters: [
    "chapters/chapter_1.js",
    "chapters/chapter_2.js",
    "chapters/chapter_3.js",
    "chapters/chapter_4.js",
    "chapters/chapter_5.js",
    "chapters/chapter_6.js",
    "chapters/chapter_7.js"
  ]
};
