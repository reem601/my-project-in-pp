// Picks and shows one of the three endings described in the design
// document.

#ifndef TENEBRIS_SRC_ENDING_MANAGER_H_
#define TENEBRIS_SRC_ENDING_MANAGER_H_

#include <string>

#include "src/content_database.h"
#include "src/dialogue.h"

namespace tenebris {

class Player;

class EndingManager {
 public:
  EndingManager(const ContentDatabase* content, Dialogue* dialogue)
      : content_(content), dialogue_(dialogue) {}

  EndingManager(const EndingManager&) = delete;
  EndingManager& operator=(const EndingManager&) = delete;

  // Reads the flags and gauges the run ended with and names an ending.
  std::string DetermineEnding(const Player& player) const;

  void ShowEnding(const std::string& ending_id, const Player& player) const;

 private:
  const ContentDatabase* const content_;
  Dialogue* const dialogue_;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_ENDING_MANAGER_H_
