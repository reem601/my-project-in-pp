#include "src/ending_manager.h"

#include <string>

#include "src/console.h"
#include "src/content_database.h"
#include "src/dialogue.h"
#include "src/js_value.h"
#include "src/player.h"

namespace tenebris {

std::string EndingManager::DetermineEnding(const Player& player) const {
  // She only walks out with her friend when she is still standing herself.
  if (player.HasFlag("friend_freed") && player.alive() && !player.broken()) {
    return "good";
  }
  if (player.HasFlag("escaped_alone")) return "neutral";
  if (player.HasFlag("defeated_shadow_lord")) return "neutral";
  return "bad";
}

void EndingManager::ShowEnding(const std::string& ending_id,
                               const Player& player) const {
  const JsValue& ending = FindById(content_->endings(), ending_id);
  if (ending.is_null()) {
    dialogue_->ShowUi("error_missing_ending", {ending_id});
    return;
  }
  dialogue_->ShowTitle(ending.Get("title").AsString(ending_id));
  dialogue_->ShowText(ending.Get("text").AsStringList());
  console::PrintBlank();
  dialogue_->ShowStatus(player);
  dialogue_->ShowUi("ending_footer");
}

}  // namespace tenebris
