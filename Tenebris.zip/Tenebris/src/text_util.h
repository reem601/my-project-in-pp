// UTF-8 aware string helpers shared by the console layer, the content
// loader and the puzzle answer matching.

#ifndef TENEBRIS_SRC_TEXT_UTIL_H_
#define TENEBRIS_SRC_TEXT_UTIL_H_

#include <cstddef>
#include <string>
#include <vector>

namespace tenebris {
namespace text_util {

std::string Trim(const std::string& text);

// Lowercases ASCII and Cyrillic letters and folds "ё" into "е" so that
// player answers match regardless of typing habits.
std::string Normalize(const std::string& text);

// Number of UTF-8 code points, used for column aware layout.
std::size_t GlyphCount(const std::string& text);

// Breaks `text` into lines of at most `width` code points, on word bounds.
std::vector<std::string> Wrap(const std::string& text, std::size_t width);

std::string ReplaceAll(const std::string& text, const std::string& from,
                       const std::string& to);

// Replaces the placeholders {0}, {1}, ... with the matching entry of `args`.
std::string Format(const std::string& pattern,
                   const std::vector<std::string>& args);

std::string FromInt(int value);

}  // namespace text_util
}  // namespace tenebris

#endif  // TENEBRIS_SRC_TEXT_UTIL_H_
