// Builds the concrete Enemy subclass named by a content definition.

#ifndef TENEBRIS_SRC_ENEMY_FACTORY_H_
#define TENEBRIS_SRC_ENEMY_FACTORY_H_

#include <memory>
#include <string>

#include "src/content_database.h"
#include "src/enemy.h"

namespace tenebris {

// Returns null when `enemy_id` is not declared in content/enemies.js.
std::unique_ptr<Enemy> CreateEnemy(const ContentDatabase& content,
                                   const std::string& enemy_id);

}  // namespace tenebris

#endif  // TENEBRIS_SRC_ENEMY_FACTORY_H_
