// Narration and player input: prints scene text, offers numbered choices
// and handles the service commands available at any prompt.

#ifndef TENEBRIS_SRC_DIALOGUE_H_
#define TENEBRIS_SRC_DIALOGUE_H_

#include <string>
#include <vector>

#include "src/content_database.h"

namespace tenebris {

class Player;

// One line of a choice menu.
struct ChoiceOption {
  std::string text;
  bool enabled = true;
  // Shown instead of moving on when a disabled option is picked.
  std::string locked_text;
};

class Dialogue {
 public:
  // Returned by PresentChoices when the player leaves the game.
  static constexpr int kQuitRequested = -1;

  explicit Dialogue(const ContentDatabase* content) : content_(content) {}

  Dialogue(const Dialogue&) = delete;
  Dialogue& operator=(const Dialogue&) = delete;

  void ShowText(const std::vector<std::string>& lines) const;
  void ShowLine(const std::string& line) const;
  void ShowTitle(const std::string& title) const;

  // Prints an interface string looked up by key.
  void ShowUi(const std::string& key) const;
  void ShowUi(const std::string& key,
              const std::vector<std::string>& args) const;

  void ShowStatus(const Player& player) const;
  void ShowInventory(const Player& player) const;
  void ShowHelp() const;

  // Prints the numbered options and reads commands until the player picks a
  // usable one. Returns its index, or kQuitRequested.
  int PresentChoices(const std::vector<ChoiceOption>& options, Player* player);

  // Reads a free form answer, used by puzzles and by the combat menu.
  // Returns false when the player leaves the game.
  bool AskAnswer(const std::string& prompt, Player* player,
                 std::string* answer);

  // Lists the usable items and asks which one to spend. Returns true when an
  // item was actually used, which is what makes a combat turn count.
  bool UseItemInteractive(Player* player);

  bool quit_requested() const { return quit_requested_; }

 private:
  // True when `word` is one of the aliases declared for `command` in
  // content/ui.js.
  bool IsCommand(const std::string& word, const std::string& command) const;

  // Runs status, inventory, help, use and quit. Returns true when `input`
  // was consumed as a service command.
  bool HandleServiceCommand(const std::string& input, Player* player);

  bool UseItemByToken(const std::string& token, Player* player) const;

  const ContentDatabase* const content_;
  bool quit_requested_ = false;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_DIALOGUE_H_
