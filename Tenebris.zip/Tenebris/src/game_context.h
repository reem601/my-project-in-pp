// Bundle of shared services handed to chapters, puzzles and encounters.

#ifndef TENEBRIS_SRC_GAME_CONTEXT_H_
#define TENEBRIS_SRC_GAME_CONTEXT_H_

namespace tenebris {

class CombatSystem;
class ContentDatabase;
class Dialogue;

struct GameContext {
  const ContentDatabase* content = nullptr;
  Dialogue* dialogue = nullptr;
  CombatSystem* combat = nullptr;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_GAME_CONTEXT_H_
