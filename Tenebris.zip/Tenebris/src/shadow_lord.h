// The Shadow Lord: the final boss with a scripted move set.

#ifndef TENEBRIS_SRC_SHADOW_LORD_H_
#define TENEBRIS_SRC_SHADOW_LORD_H_

#include "src/enemy.h"
#include "src/js_value.h"

namespace tenebris {

class Player;

class ShadowLord : public Enemy {
 public:
  // Below this hit point value the boss starts feeding on the heroine.
  static constexpr int kFearFeedingHpThreshold = 50;

  explicit ShadowLord(const JsValue& def);

  // Deals damage and tears at the psychological gauge.
  AttackOutcome DarkScream(Player* player, bool evaded);

  // Spawns copies that seal the heroine's abilities for a turn.
  AttackOutcome CreateIllusions(Player* player, bool evaded);

  // Restores the boss's own hit points while the heroine is weak.
  AttackOutcome DevourFear(Player* player, bool evaded);

  // Takes the shape of someone she trusts.
  AttackOutcome FalseImage(Player* player, bool evaded);

  AttackOutcome Attack(Player* player, bool evaded) override;

 private:
  // Reads one named move from the "special" section of the definition.
  static EnemyAttack LoadMove(const JsValue& def, const char* key);

  EnemyAttack dark_scream_;
  EnemyAttack illusions_;
  EnemyAttack devour_fear_;
  EnemyAttack false_image_;
  int devour_amount_ = 15;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_SHADOW_LORD_H_
