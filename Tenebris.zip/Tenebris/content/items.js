// Предметы. kind: heal | mental | key | quest.
// heal и mental расходуются при использовании, key и quest — нет.
// В use_text: {0} — название предмета, {1} — сколько восстановлено.

Tenebris.content.items = [
  {
    id: "apple",
    name: "Яблоко",
    description: "Восстанавливает 25 HP",
    kind: "heal",
    power: 25,
    use_text: "Вы съедаете яблоко. Тепло возвращается: +{1} HP."
  },
  {
    id: "dried_apple",
    name: "Сушёное яблоко",
    description: "Восстанавливает 15 HP",
    kind: "heal",
    power: 15,
    use_text: "Жёсткое, но своё, из дома. +{1} HP."
  },
  {
    id: "crystal",
    name: "Кристалл ясности",
    description: "Восстанавливает 30 очков психики",
    kind: "mental",
    power: 30,
    use_text: "Кристалл теплеет в ладони, и мысли проясняются: +{1}."
  },
  {
    id: "small_crystal",
    name: "Осколок кристалла",
    description: "Восстанавливает 15 очков психики",
    kind: "mental",
    power: 15,
    use_text: "Осколок гаснет, отдав вам последнюю искру: +{1}."
  },
  {
    id: "diary",
    name: "Дневник Элиана",
    description: "Записи о мире теней и обряде перехода",
    kind: "quest"
  },
  {
    id: "ancient_symbol",
    name: "Древний символ",
    description: "Каменный диск с вырезанной спиралью",
    kind: "quest"
  },
  {
    id: "friend_token",
    name: "Компас Элиана",
    description: "Личная вещь друга: стрелка всегда смотрит на него",
    kind: "quest"
  },
  {
    id: "amulet",
    name: "Старый амулет",
    description: "Магический амулет, тёплый на ощупь",
    kind: "quest"
  },
  {
    id: "cellar_key",
    name: "Ключ от подвала",
    description: "Ржавый ключ с биркой «низ»",
    kind: "key"
  },
  {
    id: "tower_key",
    name: "Ключ Башни",
    description: "Ключ из чёрного стекла",
    kind: "key"
  },
  {
    id: "lantern",
    name: "Фонарь-светляк",
    description: "Слабый, но упрямый свет",
    kind: "quest"
  },
  {
    id: "memory_shard",
    name: "Осколок памяти",
    description: "В нём отражается день, которого вы не помните",
    kind: "quest"
  }
];
