// Loads every content/*.js file and exposes the parsed game data.

#ifndef TENEBRIS_SRC_CONTENT_DATABASE_H_
#define TENEBRIS_SRC_CONTENT_DATABASE_H_

#include <string>
#include <vector>

#include "src/js_value.h"

namespace tenebris {

class ContentDatabase {
 public:
  ContentDatabase() = default;

  // Reads content/index.js from `content_dir` and then every file it lists.
  // Returns false and fills *error on a missing or malformed file.
  bool Load(const std::string& content_dir, std::string* error);

  const JsValue& ui() const { return ui_; }
  const JsValue& items() const { return items_; }
  const JsValue& enemies() const { return enemies_; }
  const JsValue& puzzles() const { return puzzles_; }
  const JsValue& endings() const { return endings_; }
  const std::vector<JsValue>& chapters() const { return chapters_; }

  // Interface string by key; falls back to the key itself so that a missing
  // entry is visible instead of silently empty.
  std::string Text(const std::string& key) const;

  // Interface string with {0}, {1}, ... substituted.
  std::string Text(const std::string& key,
                   const std::vector<std::string>& args) const;

  // Multi line interface entry, such as the help screen.
  std::vector<std::string> TextList(const std::string& key) const;

 private:
  JsValue ui_;
  JsValue items_;
  JsValue enemies_;
  JsValue puzzles_;
  JsValue endings_;
  std::vector<JsValue> chapters_;
};

// Picks the first directory that holds index.js, starting from `hint` and
// then walking up from the working directory. This lets the game run both
// from the Visual Studio project directory and from the build output folder.
bool LocateContentDir(const std::string& hint, std::string* content_dir);

}  // namespace tenebris

#endif  // TENEBRIS_SRC_CONTENT_DATABASE_H_
