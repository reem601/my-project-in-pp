// Глава 2. Портал в мир теней.
// Первая развилка доверия: кому-то из теней придётся поверить.

Tenebris.content.chapter_2 = {
  id: "chapter_2",
  title: "Глава 2. Портал в мир теней",
  start: "arrival",

  intro: [
    "Падение длится недолго и заканчивается мягко — слишком мягко.",
    "Здесь нет неба. Есть высота, и в ней что-то шевелится."
  ],

  nodes: [
    {
      id: "arrival",
      text: [
        "Равнина из плотного серого воздуха. Вдалеке — неподвижный огонёк.",
        "Ближе, слева, темнота гуще обычного, и оттуда доносится шёпот",
        "вашим собственным голосом."
      ],
      choices: [
        {
          text: "Идти на далёкий огонёк",
          next: "shade_gate"
        },
        {
          text: "Пойти на шёпот",
          next: "whisper_field"
        }
      ]
    },

    {
      id: "shade_gate",
      type: "puzzle",
      puzzle: "shade_riddle",
      on_solve: "crossroads",
      on_fail: "crossroads"
    },

    {
      id: "whisper_field",
      text: [
        "Шёпот обрывается ровно тогда, когда вы подходите достаточно близко."
      ],
      type: "combat",
      enemy: "whisperer",
      on_win: "crossroads",
      on_win_effects: {
        mental: 10,
        text: ["Вы выдерживаете собственный голос. Это чего-то стоит."]
      },
      on_lose: "whisper_wake",
      revive_hp: 25,
      revive_mental: 20
    },

    {
      id: "whisper_wake",
      text: [
        "Вы приходите в себя на камне у перекрёстка. Шёпот ушёл, забрав",
        "с собой кусок вашей уверенности."
      ],
      on_enter: {
        mental: -10
      },
      next: "crossroads"
    },

    {
      id: "crossroads",
      text: [
        "Перекрёсток трёх дорог. На камне сидит тень, похожая на старика,",
        "и чинит фонарь, которого нет."
      ],
      revisit_text: ["Перекрёсток. Старик всё ещё чинит пустоту."],
      choices: [
        {
          text: "Заговорить со стариком",
          forbid_flags: ["talked_to_guide"],
          hidden: true,
          next: "guide_talk"
        },
        {
          text: "Идти дальше",
          next: "chapter_2_end"
        }
      ]
    },

    {
      id: "guide_talk",
      text: [
        "«Ты ищешь мальчика с компасом», — говорит он, не поднимая головы.",
        "«Он в Башне. Я покажу дорогу. Взамен — вспомни обо мне, когда",
        "будешь уходить. Здесь забывают быстро»."
      ],
      on_enter: {
        set: ["talked_to_guide"]
      },
      choices: [
        {
          text: "Пообещать и принять помощь",
          effects: {
            set: ["trusted_guide"],
            give: ["small_crystal"],
            mental: 8,
            text: ["Старик вкладывает вам в ладонь осколок кристалла."]
          },
          next: "crossroads"
        },
        {
          text: "Отказаться: здесь никому нельзя верить",
          effects: {
            set: ["refused_guide"],
            mental: -5,
            text: ["Старик кивает, будто ждал этого. Фонарь в его руках гаснет."]
          },
          next: "crossroads"
        }
      ]
    },

    {
      id: "chapter_2_end",
      type: "chapter_end"
    }
  ]
};
