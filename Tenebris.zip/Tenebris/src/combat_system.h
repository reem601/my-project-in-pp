// Turn based combat: the heroine acts, then the shadow answers.

#ifndef TENEBRIS_SRC_COMBAT_SYSTEM_H_
#define TENEBRIS_SRC_COMBAT_SYSTEM_H_

#include "src/content_database.h"
#include "src/dialogue.h"

namespace tenebris {

class Enemy;
class Player;

enum class BattleResult {
  kVictory,
  kDefeat,  // Hit points or the psychological gauge ran out.
  kQuit,    // The player left the game from the combat menu.
};

class CombatSystem {
 public:
  CombatSystem(const ContentDatabase* content, Dialogue* dialogue)
      : content_(content), dialogue_(dialogue) {}

  CombatSystem(const CombatSystem&) = delete;
  CombatSystem& operator=(const CombatSystem&) = delete;

  // Runs a full encounter against `enemy`.
  BattleResult StartBattle(Player* player, Enemy* enemy);

 private:
  // Moves available to the heroine. The last three belong to the scripted
  // final battle described in the design document.
  enum class Move {
    kAttack,
    kDefend,
    kDodge,
    kShadowPower,
    kUseItem,
    kSkipTurn,
    kShadowStrike,
    kWillpower,
    kLightShield,
    kHiddenAttack,
  };

  // Offers the menu and applies the chosen move. Returns false when the
  // player quit the game.
  bool PlayerTurn(Player* player, Enemy* enemy);

  // Plays the enemy answer for this round.
  void EnemyTurn(Player* player, Enemy* enemy);

  void ShowGauges(const Player& player, const Enemy& enemy) const;
  void ApplyPlayerDamage(int damage, Enemy* enemy);

  const ContentDatabase* const content_;
  Dialogue* const dialogue_;

  // Round state, reset by StartBattle.
  int sealed_turns_ = 0;  // Illusions block the special moves.
  bool dodging_ = false;  // Set when the heroine spends the turn evading.
  bool hidden_ready_ = false;
  bool shielded_ = false;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_COMBAT_SYSTEM_H_
