// A riddle declared in content/puzzles.js.

#ifndef TENEBRIS_SRC_PUZZLE_H_
#define TENEBRIS_SRC_PUZZLE_H_

#include <string>

#include "src/game_context.h"
#include "src/js_value.h"

namespace tenebris {

class Player;

class Puzzle {
 public:
  Puzzle(const JsValue& def, const GameContext& context);

  // Plays the riddle to a conclusion; returns true when it was solved.
  bool Solve(Player* player);

 private:
  // Compares a normalized answer against every accepted spelling.
  bool IsCorrect(const std::string& answer) const;

  const JsValue& def_;
  GameContext context_;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_PUZZLE_H_
