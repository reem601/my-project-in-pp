#include "src/content_database.h"

#include <fstream>
#include <string>
#include <utility>
#include <vector>

#include "src/js_parser.h"
#include "src/js_value.h"
#include "src/text_util.h"

namespace tenebris {
namespace {

bool FileExists(const std::string& path) {
  std::ifstream stream(path.c_str(), std::ios::binary);
  return stream.is_open();
}

std::string JoinPath(const std::string& directory, const std::string& name) {
  if (directory.empty()) return name;
  const char last = directory[directory.size() - 1];
  if (last == '/' || last == '\\') return directory + name;
  return directory + "/" + name;
}

bool LoadSection(const std::string& content_dir, const JsValue& manifest,
                 const std::string& key, JsValue* out, std::string* error) {
  const std::string file_name = manifest.Get(key).AsString();
  if (file_name.empty()) {
    *error = "index.js does not declare the section '" + key + "'";
    return false;
  }
  return js_parser::ParseFile(JoinPath(content_dir, file_name), out, error);
}

}  // namespace

bool ContentDatabase::Load(const std::string& content_dir, std::string* error) {
  JsValue manifest;
  if (!js_parser::ParseFile(JoinPath(content_dir, "index.js"), &manifest,
                            error)) {
    return false;
  }
  if (!LoadSection(content_dir, manifest, "ui", &ui_, error)) return false;
  if (!LoadSection(content_dir, manifest, "items", &items_, error)) {
    return false;
  }
  if (!LoadSection(content_dir, manifest, "enemies", &enemies_, error)) {
    return false;
  }
  if (!LoadSection(content_dir, manifest, "puzzles", &puzzles_, error)) {
    return false;
  }
  if (!LoadSection(content_dir, manifest, "endings", &endings_, error)) {
    return false;
  }

  const JsValue& chapter_files = manifest.Get("chapters");
  if (!chapter_files.is_array() || chapter_files.size() == 0) {
    *error = "index.js does not declare any chapter files";
    return false;
  }
  chapters_.clear();
  for (const JsValue& entry : chapter_files.elements()) {
    JsValue chapter;
    if (!js_parser::ParseFile(JoinPath(content_dir, entry.AsString()), &chapter,
                              error)) {
      return false;
    }
    chapters_.push_back(std::move(chapter));
  }
  return true;
}

std::string ContentDatabase::Text(const std::string& key) const {
  const JsValue& value = ui_.Get(key);
  if (value.is_null()) return key;
  return value.AsString(key);
}

std::string ContentDatabase::Text(const std::string& key,
                                  const std::vector<std::string>& args) const {
  return text_util::Format(Text(key), args);
}

std::vector<std::string> ContentDatabase::TextList(
    const std::string& key) const {
  const JsValue& value = ui_.Get(key);
  if (value.is_null()) return std::vector<std::string>(1, key);
  return value.AsStringList();
}

bool LocateContentDir(const std::string& hint, std::string* content_dir) {
  std::vector<std::string> candidates;
  if (!hint.empty()) candidates.push_back(hint);
  candidates.push_back("content");
  candidates.push_back("../content");
  candidates.push_back("../../content");
  candidates.push_back("../../../content");
  candidates.push_back("../../../../content");
  for (const std::string& candidate : candidates) {
    if (FileExists(JoinPath(candidate, "index.js"))) {
      *content_dir = candidate;
      return true;
    }
  }
  return false;
}

}  // namespace tenebris
