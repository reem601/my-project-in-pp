#include "src/rng.h"

#include <random>

namespace tenebris {
namespace rng {
namespace {

std::mt19937& Engine() {
  static std::random_device device;
  static std::mt19937 engine(device());
  return engine;
}

}  // namespace

void Seed(unsigned int seed) { Engine().seed(seed); }

int Range(int low, int high) {
  if (low >= high) return low;
  std::uniform_int_distribution<int> distribution(low, high);
  return distribution(Engine());
}

bool Chance(int percent) {
  if (percent <= 0) return false;
  if (percent >= 100) return true;
  return Range(1, 100) <= percent;
}

}  // namespace rng
}  // namespace tenebris
