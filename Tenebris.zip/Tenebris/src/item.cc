#include "src/item.h"

#include <string>
#include <vector>

#include "src/content_database.h"
#include "src/js_value.h"
#include "src/player.h"
#include "src/text_util.h"

namespace tenebris {
namespace {

ItemKind KindFromString(const std::string& text) {
  if (text == "heal") return ItemKind::kHeal;
  if (text == "mental") return ItemKind::kMental;
  if (text == "key") return ItemKind::kKey;
  return ItemKind::kQuest;
}

}  // namespace

Item Item::FromJs(const JsValue& def) {
  Item item;
  item.id_ = def.Get("id").AsString();
  item.name_ = def.Get("name").AsString(item.id_);
  item.description_ = def.Get("description").AsString();
  item.use_text_ = def.Get("use_text").AsString();
  item.kind_ = KindFromString(def.Get("kind").AsString("quest"));
  item.power_ = def.Get("power").AsInt(0);
  const bool default_consumable =
      item.kind_ == ItemKind::kHeal || item.kind_ == ItemKind::kMental;
  item.consumable_ = def.Get("consumable").AsBool(default_consumable);
  return item;
}

bool Item::HasEffectOn(const Player& player) const {
  switch (kind_) {
    case ItemKind::kHeal:
      return player.hp() < Player::kMaxHp;
    case ItemKind::kMental:
      return player.mental_state() < Player::kMaxMental;
    default:
      return false;
  }
}

std::string Item::Use(Player* player) const {
  int restored = 0;
  switch (kind_) {
    case ItemKind::kHeal: {
      const int before = player->hp();
      player->ChangeHp(power_);
      restored = player->hp() - before;
      break;
    }
    case ItemKind::kMental: {
      const int before = player->mental_state();
      player->ChangeMental(power_);
      restored = player->mental_state() - before;
      break;
    }
    default:
      return use_text_;
  }
  return text_util::Format(use_text_, {name_, text_util::FromInt(restored)});
}

bool GrantItem(const ContentDatabase& content, const std::string& item_id,
               Player* player) {
  const JsValue& def = FindById(content.items(), item_id);
  if (def.is_null()) return false;
  player->inventory().AddItem(Item::FromJs(def));
  return true;
}

}  // namespace tenebris
