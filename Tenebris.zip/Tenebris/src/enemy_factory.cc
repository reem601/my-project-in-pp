#include "src/enemy_factory.h"

#include <memory>
#include <string>

#include "src/content_database.h"
#include "src/enemy.h"
#include "src/js_value.h"
#include "src/shadow_lord.h"

namespace tenebris {

std::unique_ptr<Enemy> CreateEnemy(const ContentDatabase& content,
                                   const std::string& enemy_id) {
  const JsValue& def = FindById(content.enemies(), enemy_id);
  if (def.is_null()) return nullptr;
  if (def.Get("boss").AsBool(false)) {
    return std::unique_ptr<Enemy>(new ShadowLord(def));
  }
  return std::unique_ptr<Enemy>(new Enemy(def));
}

}  // namespace tenebris
