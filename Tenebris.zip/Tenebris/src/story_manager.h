// Hands out the chapters in the order declared by content/index.js.

#ifndef TENEBRIS_SRC_STORY_MANAGER_H_
#define TENEBRIS_SRC_STORY_MANAGER_H_

#include <cstddef>
#include <memory>

#include "src/chapter.h"
#include "src/content_database.h"
#include "src/game_context.h"

namespace tenebris {

class StoryManager {
 public:
  StoryManager(const ContentDatabase* content, const GameContext& context)
      : content_(content), context_(context) {}

  bool HasNext() const { return index_ < content_->chapters().size(); }

  // Builds the next chapter; returns null once the story is over.
  std::unique_ptr<Chapter> NextChapter();

  // One based number of the chapter returned last.
  int chapter_number() const { return static_cast<int>(index_); }

 private:
  const ContentDatabase* const content_;
  GameContext context_;
  std::size_t index_ = 0;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_STORY_MANAGER_H_
