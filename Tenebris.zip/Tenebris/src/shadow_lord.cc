#include "src/shadow_lord.h"

#include "src/enemy.h"
#include "src/js_value.h"
#include "src/player.h"
#include "src/rng.h"

namespace tenebris {

ShadowLord::ShadowLord(const JsValue& def) : Enemy(def) {
  is_boss_ = true;
  dark_scream_ = LoadMove(def, "dark_scream");
  illusions_ = LoadMove(def, "illusions");
  devour_fear_ = LoadMove(def, "devour_fear");
  false_image_ = LoadMove(def, "false_image");
  devour_amount_ = def.Get("special").Get("devour_fear").Get("heal").AsInt(15);
}

EnemyAttack ShadowLord::LoadMove(const JsValue& def, const char* key) {
  const JsValue& entry = def.Get("special").Get(key);
  EnemyAttack move;
  move.name = entry.Get("name").AsString(key);
  move.text = entry.Get("text").AsString(move.name);
  move.hp_damage = entry.Get("hp_damage").AsInt(0);
  move.mental_damage = entry.Get("mental_damage").AsInt(0);
  move.blocked_turns = entry.Get("blocked_turns").AsInt(0);
  return move;
}

AttackOutcome ShadowLord::DarkScream(Player* player, bool evaded) {
  return Apply(dark_scream_, player, evaded);
}

AttackOutcome ShadowLord::CreateIllusions(Player* player, bool evaded) {
  return Apply(illusions_, player, evaded);
}

AttackOutcome ShadowLord::FalseImage(Player* player, bool evaded) {
  return Apply(false_image_, player, evaded);
}

AttackOutcome ShadowLord::DevourFear(Player* player, bool evaded) {
  AttackOutcome outcome = Apply(devour_fear_, player, evaded);
  if (!evaded) {
    const int before = hp();
    Heal(devour_amount_);
    outcome.healed = hp() - before;
  }
  return outcome;
}

AttackOutcome ShadowLord::Attack(Player* player, bool evaded) {
  // The boss feeds on a wounded heroine, then leans on whichever of her two
  // gauges is still holding.
  if (player->hp() < kFearFeedingHpThreshold && hp() < max_hp() &&
      rng::Chance(45)) {
    return DevourFear(player, evaded);
  }
  if (rng::Chance(25)) return CreateIllusions(player, evaded);
  if (player->mental_state() > Player::kFragileMental && rng::Chance(30)) {
    return DarkScream(player, evaded);
  }
  if (rng::Chance(30)) return FalseImage(player, evaded);
  return Enemy::Attack(player, evaded);
}

}  // namespace tenebris
