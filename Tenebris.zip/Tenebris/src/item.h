// A single inventory entry declared in content/items.js.

#ifndef TENEBRIS_SRC_ITEM_H_
#define TENEBRIS_SRC_ITEM_H_

#include <string>

#include "src/content_database.h"
#include "src/js_value.h"

namespace tenebris {

class Player;

enum class ItemKind {
  kHeal,    // Restores hit points.
  kMental,  // Restores the psychological gauge.
  kKey,     // Opens a specific way forward.
  kQuest,   // Story item, carried but never spent.
};

class Item {
 public:
  Item() = default;

  static Item FromJs(const JsValue& def);

  const std::string& id() const { return id_; }
  const std::string& name() const { return name_; }
  const std::string& description() const { return description_; }
  ItemKind kind() const { return kind_; }
  int power() const { return power_; }
  bool consumable() const { return consumable_; }
  bool usable() const {
    return kind_ == ItemKind::kHeal || kind_ == ItemKind::kMental;
  }

  // False when using the item right now would change nothing, for example
  // a healing item at full health.
  bool HasEffectOn(const Player& player) const;

  // Applies the effect to `player` and returns the line to show.
  std::string Use(Player* player) const;

 private:
  std::string id_;
  std::string name_;
  std::string description_;
  std::string use_text_;
  ItemKind kind_ = ItemKind::kQuest;
  int power_ = 0;
  bool consumable_ = true;
};

// Looks `item_id` up in content/items.js and hands it to the player.
// Returns false when the identifier is unknown.
bool GrantItem(const ContentDatabase& content, const std::string& item_id,
               Player* player);

}  // namespace tenebris

#endif  // TENEBRIS_SRC_ITEM_H_
