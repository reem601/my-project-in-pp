// The heroine's carried items.

#ifndef TENEBRIS_SRC_INVENTORY_H_
#define TENEBRIS_SRC_INVENTORY_H_

#include <cstddef>
#include <string>
#include <vector>

#include "src/item.h"

namespace tenebris {

class Player;

class Inventory {
 public:
  Inventory() = default;

  void AddItem(const Item& item);

  // Removes one copy of `id`; returns false when it is not carried.
  bool RemoveItem(const std::string& id);

  bool Has(const std::string& id) const;
  const Item* Find(const std::string& id) const;

  // Uses the item, writes the resulting line into *message and drops the
  // item when it is consumable. Returns false when it cannot be used.
  bool UseItem(const std::string& id, Player* player, std::string* message);

  const std::vector<Item>& items() const { return items_; }
  bool empty() const { return items_.empty(); }
  std::size_t size() const { return items_.size(); }

 private:
  std::vector<Item> items_;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_INVENTORY_H_
