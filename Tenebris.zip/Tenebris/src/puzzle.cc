#include "src/puzzle.h"

#include <cstddef>
#include <string>
#include <vector>

#include "src/content_database.h"
#include "src/dialogue.h"
#include "src/item.h"
#include "src/js_value.h"
#include "src/player.h"
#include "src/text_util.h"

namespace tenebris {
namespace {

constexpr int kDefaultAttempts = 3;

}  // namespace

Puzzle::Puzzle(const JsValue& def, const GameContext& context)
    : def_(def), context_(context) {}

bool Puzzle::IsCorrect(const std::string& answer) const {
  const std::string normalized = text_util::Normalize(answer);
  for (const JsValue& accepted : def_.Get("answers").elements()) {
    if (text_util::Normalize(accepted.AsString()) == normalized) return true;
  }
  return false;
}

bool Puzzle::Solve(Player* player) {
  Dialogue* const dialogue = context_.dialogue;
  const ContentDatabase& content = *context_.content;

  dialogue->ShowText(def_.Get("text").AsStringList());

  const std::vector<std::string> hints = def_.Get("hints").AsStringList();
  const int attempts = def_.Get("attempts").AsInt(kDefaultAttempts);
  const std::string prompt =
      def_.Get("prompt").AsString(content.Text("puzzle_prompt"));

  for (int attempt = 0; attempt < attempts; ++attempt) {
    std::string answer;
    if (!dialogue->AskAnswer(prompt, player, &answer)) return false;
    if (IsCorrect(answer)) {
      dialogue->ShowText(def_.Get("success_text").AsStringList());
      player->ChangeMental(def_.Get("mental_reward").AsInt(0));
      const std::string reward = def_.Get("reward_item").AsString();
      if (!reward.empty()) GrantItem(content, reward, player);
      const std::string flag = def_.Get("set_flag").AsString();
      if (!flag.empty()) player->SetFlag(flag);
      return true;
    }

    const int remaining = attempts - attempt - 1;
    dialogue->ShowUi("puzzle_wrong", {text_util::FromInt(remaining)});
    player->ChangeMental(-def_.Get("mental_penalty").AsInt(0));
    if (remaining > 0 && !hints.empty()) {
      const std::size_t hint_index =
          static_cast<std::size_t>(attempt) < hints.size()
              ? static_cast<std::size_t>(attempt)
              : hints.size() - 1;
      dialogue->ShowUi("puzzle_hint", {hints[hint_index]});
    }
  }

  dialogue->ShowText(def_.Get("fail_text").AsStringList());
  player->ChangeHp(-def_.Get("hp_penalty").AsInt(0));
  const std::string fail_flag = def_.Get("fail_flag").AsString();
  if (!fail_flag.empty()) player->SetFlag(fail_flag);
  return false;
}

}  // namespace tenebris
