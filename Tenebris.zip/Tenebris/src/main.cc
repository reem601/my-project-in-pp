// Tenebris - a text adventure in the world of shadows.
//
// Usage: Tenebris [content_dir] [seed]
//   content_dir  Path to the content/ folder; found automatically when
//                omitted.
//   seed         Fixed seed for the random generator, useful for testing.

#include <cstdlib>
#include <string>

#include "src/console.h"
#include "src/game.h"
#include "src/rng.h"

int main(int argc, char** argv) {
  tenebris::console::Initialize();

  const std::string content_dir_hint = argc > 1 ? argv[1] : "";
  if (argc > 2) {
    tenebris::rng::Seed(
        static_cast<unsigned int>(std::strtoul(argv[2], nullptr, 10)));
  }

  tenebris::Game game;
  return game.Start(content_dir_hint) ? 0 : 1;
}
