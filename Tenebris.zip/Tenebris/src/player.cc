#include "src/player.h"

#include "src/rng.h"

namespace tenebris {

void Player::ChangeHp(int delta) {
  hp_ += delta;
  if (hp_ > kMaxHp) hp_ = kMaxHp;
  if (hp_ < 0) hp_ = 0;
}

void Player::ChangeMental(int delta) {
  mental_state_ += delta;
  if (mental_state_ > kMaxMental) mental_state_ = kMaxMental;
  if (mental_state_ < 0) mental_state_ = 0;
}

int Player::Attack() const {
  int damage = rng::Range(kMinAttackDamage, kMaxAttackDamage);
  // A frightened heroine strikes with less conviction.
  if (fragile()) damage -= damage / 4;
  return damage;
}

void Player::Defend() { guarding_ = true; }

bool Player::Dodge() const {
  const int chance = fragile() ? kDodgeChancePercent - 15 : kDodgeChancePercent;
  return rng::Chance(chance);
}

int Player::TakeDamage(int hp_damage, int mental_damage) {
  int damage = hp_damage;
  if (guarding_) {
    damage -= damage * kGuardReductionPercent / 100;
    guarding_ = false;
  }
  if (fragile()) damage += damage / 2;
  if (damage < 0) damage = 0;
  const int before = hp_;
  ChangeHp(-damage);
  ChangeMental(-mental_damage);
  return before - hp_;
}

}  // namespace tenebris
