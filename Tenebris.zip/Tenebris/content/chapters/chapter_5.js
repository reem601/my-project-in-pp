// Глава 5. Башня Теней.
// Три препятствия подряд: страж, загадка лестницы и призрак сомнения.

Tenebris.content.chapter_5 = {
  id: "chapter_5",
  title: "Глава 5. Башня Теней",
  start: "tower_gate",

  intro: [
    "Спуск в долину занимает не то час, не то сутки — здесь это одно",
    "и то же. Башня вблизи оказывается не каменной. Она сложена из",
    "застывшего дыма."
  ],

  nodes: [
    {
      id: "tower_gate",
      text: [
        "Ворот нет: есть проём, который то шире, то уже вашего плеча.",
        "У проёма стоит доспех без человека внутри."
      ],
      choices: [
        {
          text: "Войти прямо, не скрываясь",
          next: "tower_guard_fight"
        },
        {
          text: "Показать стражу компас Элиана",
          require_items: ["friend_token"],
          locked_text: "Показывать нечего.",
          effects: {
            mental: 5,
            text: [
              "Доспех наклоняется к компасу — и всё-таки заносит руку.",
              "Но заносит медленнее, чем мог бы."
            ]
          },
          next: "tower_guard_fight"
        }
      ]
    },

    {
      id: "tower_guard_fight",
      type: "combat",
      enemy: "tower_guard",
      on_win: "tower_stairs",
      on_lose: "tower_stairs",
      on_lose_effects: {
        hp: -5,
        mental: -10,
        text: ["Вы проскальзываете мимо доспеха, пока он ищет вас не там."]
      },
      revive_hp: 30,
      revive_mental: 25
    },

    {
      id: "tower_stairs",
      text: [
        "Лестница внутри вьётся против часовой стрелки и обрывается",
        "на пятом пролёте. В стене — узкая щель, похожая на ухо.",
        "",
        "На ступени лежит ваш собственный дорожный мешок — тот, что вы",
        "оставили дома. В нём еда и осколок кристалла."
      ],
      on_enter: {
        give: ["apple", "small_crystal"]
      },
      next: "tower_puzzle"
    },

    {
      id: "tower_puzzle",
      type: "puzzle",
      puzzle: "tower_riddle",
      on_solve: "tower_top",
      on_fail: "tower_ledge"
    },

    {
      id: "tower_ledge",
      text: [
        "Вы вылезаете в бойницу и идёте наверх по карнизу шириной в ладонь.",
        "Ветра здесь нет, и от этого только страшнее."
      ],
      on_enter: {
        hp: -12,
        mental: -8
      },
      next: "tower_top"
    },

    {
      id: "tower_top",
      text: [
        "Верхний этаж. Свет из окна не освещает ничего, кроме себя."
      ],
      type: "combat",
      enemy: "doubt_wraith",
      on_win: "tower_cell",
      on_win_effects: {
        mental: 12
      },
      on_lose: "tower_cell",
      on_lose_effects: {
        mental: -10
      },
      revive_hp: 25,
      revive_mental: 20
    },

    {
      id: "tower_cell",
      text: [
        "За последней дверью — комната без углов. В центре, в коконе",
        "из неподвижной тьмы, сидит Элиан. Он поднимает голову.",
        "",
        "«Ты пришла», — говорит он. — «Значит, теперь он знает про тебя»."
      ],
      on_enter: {
        set: ["found_friend"],
        give: ["apple"]
      },
      choices: [
        {
          text: "Попробовать разорвать кокон руками",
          effects: {
            hp: -10,
            mental: 5,
            text: [
              "Тьма обжигает холодом, но подаётся. Немного. Элиан качает",
              "головой: «Не здесь. Сначала он»."
            ]
          },
          next: "chapter_5_end"
        },
        {
          text: "Спросить, как его освободить",
          effects: {
            set: ["knows_the_way"],
            mental: 10,
            text: [
              "«Он держит меня страхом. Не моим — твоим. Перестанешь",
              "бояться — кокон разожмётся сам»."
            ]
          },
          next: "chapter_5_end"
        }
      ]
    },

    {
      id: "chapter_5_end",
      type: "chapter_end"
    }
  ]
};
