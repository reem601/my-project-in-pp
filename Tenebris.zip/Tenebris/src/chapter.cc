#include "src/chapter.h"

#include <cstddef>
#include <memory>
#include <string>
#include <vector>

#include "src/combat_system.h"
#include "src/content_database.h"
#include "src/dialogue.h"
#include "src/enemy.h"
#include "src/enemy_factory.h"
#include "src/item.h"
#include "src/js_value.h"
#include "src/player.h"
#include "src/puzzle.h"
#include "src/text_util.h"

namespace tenebris {
namespace {

// Hit points restored when a lost fight is written as a survivable defeat.
constexpr int kDefaultReviveHp = 20;

}  // namespace

Chapter::Chapter(const JsValue& def, const GameContext& context)
    : def_(def), context_(context) {
  id_ = def_.Get("id").AsString();
  title_ = def_.Get("title").AsString(id_);
}

const JsValue& Chapter::FindNode(const std::string& node_id) const {
  return FindById(def_.Get("nodes"), node_id);
}

void Chapter::ApplyEffects(const JsValue& effects, Player* player) {
  if (!effects.is_object()) return;
  Dialogue* const dialogue = context_.dialogue;
  const ContentDatabase& content = *context_.content;

  dialogue->ShowText(effects.Get("text").AsStringList());

  const int hp = effects.Get("hp").AsInt(0);
  if (hp != 0) {
    player->ChangeHp(hp);
    dialogue->ShowUi(hp > 0 ? "effect_hp_gain" : "effect_hp_loss",
                     {text_util::FromInt(hp > 0 ? hp : -hp)});
  }
  const int mental = effects.Get("mental").AsInt(0);
  if (mental != 0) {
    player->ChangeMental(mental);
    dialogue->ShowUi(mental > 0 ? "effect_mental_gain" : "effect_mental_loss",
                     {text_util::FromInt(mental > 0 ? mental : -mental)});
  }
  for (const std::string& item_id : effects.Get("give").AsStringList()) {
    if (!GrantItem(content, item_id, player)) continue;
    const JsValue& item_def = FindById(content.items(), item_id);
    dialogue->ShowUi("effect_item_gained",
                     {item_def.Get("name").AsString(item_id)});
  }
  for (const std::string& item_id : effects.Get("take").AsStringList()) {
    player->inventory().RemoveItem(item_id);
  }
  for (const std::string& flag : effects.Get("set").AsStringList()) {
    player->SetFlag(flag);
  }
}

bool Chapter::IsChoiceAvailable(const JsValue& choice,
                                const Player& player) const {
  for (const std::string& item_id :
       choice.Get("require_items").AsStringList()) {
    if (!player.inventory().Has(item_id)) return false;
  }
  for (const std::string& flag : choice.Get("require_flags").AsStringList()) {
    if (!player.HasFlag(flag)) return false;
  }
  for (const std::string& flag : choice.Get("forbid_flags").AsStringList()) {
    if (player.HasFlag(flag)) return false;
  }
  if (choice.Has("require_mental")) {
    if (player.mental_state() < choice.Get("require_mental").AsInt(0)) {
      return false;
    }
  }
  return true;
}

std::string Chapter::RunSceneNode(const JsValue& node, Player* player,
                                  ChapterResult* result) {
  const JsValue& choices = node.Get("choices");
  if (!choices.is_array() || choices.size() == 0) {
    return node.Get("next").AsString();
  }

  std::vector<ChoiceOption> options;
  std::vector<const JsValue*> selected;
  for (const JsValue& choice : choices.elements()) {
    const bool available = IsChoiceAvailable(choice, *player);
    if (!available && choice.Get("hidden").AsBool(false)) continue;
    ChoiceOption option;
    option.text = choice.Get("text").AsString();
    option.enabled = available;
    option.locked_text = choice.Get("locked_text").AsString();
    options.push_back(option);
    selected.push_back(&choice);
  }
  if (options.empty()) return node.Get("next").AsString();

  const int index = context_.dialogue->PresentChoices(options, player);
  if (index == Dialogue::kQuitRequested) {
    result->outcome = ChapterOutcome::kQuit;
    return std::string();
  }

  const JsValue& choice = *selected[static_cast<std::size_t>(index)];
  ApplyEffects(choice.Get("effects"), player);
  if (choice.Has("ending")) {
    result->outcome = ChapterOutcome::kEnding;
    result->ending_id = choice.Get("ending").AsString("auto");
    return std::string();
  }
  return choice.Get("next").AsString(node.Get("next").AsString());
}

std::string Chapter::RunCombatNode(const JsValue& node, Player* player,
                                   ChapterResult* result) {
  const std::string enemy_id = node.Get("enemy").AsString();
  std::unique_ptr<Enemy> enemy = CreateEnemy(*context_.content, enemy_id);
  if (enemy == nullptr) {
    context_.dialogue->ShowUi("error_missing_enemy", {enemy_id});
    return node.Get("on_win").AsString();
  }

  const BattleResult battle = context_.combat->StartBattle(player, enemy.get());
  if (battle == BattleResult::kQuit) {
    result->outcome = ChapterOutcome::kQuit;
    return std::string();
  }
  if (battle == BattleResult::kVictory) {
    ApplyEffects(node.Get("on_win_effects"), player);
    return node.Get("on_win").AsString();
  }

  ApplyEffects(node.Get("on_lose_effects"), player);
  const std::string on_lose = node.Get("on_lose").AsString();
  if (!on_lose.empty()) {
    // A scripted, survivable defeat: she wakes somewhere else, weakened.
    if (!player->alive()) {
      player->ChangeHp(node.Get("revive_hp").AsInt(kDefaultReviveHp));
    }
    if (player->broken()) {
      player->ChangeMental(node.Get("revive_mental").AsInt(kDefaultReviveHp));
    }
    return on_lose;
  }
  result->outcome = ChapterOutcome::kEnding;
  result->ending_id = node.Get("lose_ending").AsString("bad");
  return std::string();
}

std::string Chapter::RunPuzzleNode(const JsValue& node, Player* player,
                                   ChapterResult* result) {
  const std::string puzzle_id = node.Get("puzzle").AsString();
  const JsValue& def = FindById(context_.content->puzzles(), puzzle_id);
  if (def.is_null()) {
    context_.dialogue->ShowUi("error_missing_puzzle", {puzzle_id});
    return node.Get("on_solve").AsString();
  }

  Puzzle puzzle(def, context_);
  const bool solved = puzzle.Solve(player);
  if (context_.dialogue->quit_requested()) {
    result->outcome = ChapterOutcome::kQuit;
    return std::string();
  }
  if (solved) {
    ApplyEffects(node.Get("on_solve_effects"), player);
    return node.Get("on_solve").AsString();
  }
  ApplyEffects(node.Get("on_fail_effects"), player);
  if (node.Has("fail_ending")) {
    result->outcome = ChapterOutcome::kEnding;
    result->ending_id = node.Get("fail_ending").AsString("auto");
    return std::string();
  }
  return node.Get("on_fail").AsString(node.Get("on_solve").AsString());
}

ChapterResult Chapter::Start(Player* player) {
  ChapterResult result;
  Dialogue* const dialogue = context_.dialogue;
  dialogue->ShowTitle(title_);
  dialogue->ShowText(def_.Get("intro").AsStringList());

  const int move_limit = def_.Get("move_limit").AsInt(0);
  const std::string timeout_node = def_.Get("timeout_node").AsString();

  std::string current = def_.Get("start").AsString();
  while (!current.empty()) {
    const JsValue& node = FindNode(current);
    if (node.is_null()) {
      dialogue->ShowUi("error_missing_node", {current});
      return result;
    }

    const bool first_visit = visited_.insert(current).second;
    if (!first_visit && node.Has("revisit_text")) {
      dialogue->ShowText(node.Get("revisit_text").AsStringList());
    } else {
      dialogue->ShowText(node.Get("text").AsStringList());
    }
    if (first_visit || !node.Get("enter_once").AsBool(true)) {
      ApplyEffects(node.Get("on_enter"), player);
    }

    if (move_limit > 0 && !timeout_fired_) {
      const int left = move_limit - moves_spent_;
      dialogue->ShowUi("moves_left", {text_util::FromInt(left > 0 ? left : 0)});
    }

    const std::string type = node.Get("type").AsString("scene");
    std::string next;
    if (type == "combat") {
      next = RunCombatNode(node, player, &result);
    } else if (type == "puzzle") {
      next = RunPuzzleNode(node, player, &result);
    } else if (type == "ending") {
      result.outcome = ChapterOutcome::kEnding;
      result.ending_id = node.Get("ending").AsString("auto");
      return result;
    } else if (type == "chapter_end") {
      result.outcome = ChapterOutcome::kCompleted;
      return result;
    } else {
      next = RunSceneNode(node, player, &result);
    }

    if (result.outcome != ChapterOutcome::kCompleted) return result;

    // A trap or a scripted effect can finish her off outside of combat.
    if (!player->alive() || player->broken()) {
      result.outcome = ChapterOutcome::kEnding;
      result.ending_id = def_.Get("death_ending").AsString("bad");
      return result;
    }

    ++moves_spent_;
    if (move_limit > 0 && !timeout_fired_ && moves_spent_ >= move_limit &&
        !timeout_node.empty()) {
      timeout_fired_ = true;
      dialogue->ShowUi("time_is_up");
      next = timeout_node;
    }
    current = next;
  }
  return result;
}

}  // namespace tenebris
