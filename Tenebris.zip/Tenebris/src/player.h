// The heroine: hit points, the psychological gauge, carried items and the
// story flags her choices leave behind.

#ifndef TENEBRIS_SRC_PLAYER_H_
#define TENEBRIS_SRC_PLAYER_H_

#include <set>
#include <string>

#include "src/inventory.h"

namespace tenebris {

class Player {
 public:
  static constexpr int kMaxHp = 100;
  static constexpr int kMaxMental = 100;

  // Below this value fear takes over and incoming damage grows by half.
  static constexpr int kFragileMental = 30;

  static constexpr int kMinAttackDamage = 10;
  static constexpr int kMaxAttackDamage = 20;
  static constexpr int kDodgeChancePercent = 50;
  static constexpr int kGuardReductionPercent = 50;

  Player() = default;

  int hp() const { return hp_; }
  int mental_state() const { return mental_state_; }
  bool alive() const { return hp_ > 0; }
  bool broken() const { return mental_state_ <= 0; }
  bool fragile() const { return mental_state_ < kFragileMental; }
  bool guarding() const { return guarding_; }

  void ChangeHp(int delta);
  void ChangeMental(int delta);

  // Rolls a basic attack.
  int Attack() const;

  // Halves the damage of the next incoming attack.
  void Defend();

  // Rolls an evasion attempt; fear makes it less reliable.
  bool Dodge() const;

  void ClearGuard() { guarding_ = false; }

  // Applies an incoming hit, honouring the guard and the fear penalty.
  // Returns the hit points actually lost.
  int TakeDamage(int hp_damage, int mental_damage);

  void SetFlag(const std::string& flag) { flags_.insert(flag); }
  bool HasFlag(const std::string& flag) const {
    return flags_.find(flag) != flags_.end();
  }

  Inventory& inventory() { return inventory_; }
  const Inventory& inventory() const { return inventory_; }

 private:
  int hp_ = kMaxHp;
  int mental_state_ = kMaxMental;
  bool guarding_ = false;
  Inventory inventory_;
  std::set<std::string> flags_;
};

}  // namespace tenebris

#endif  // TENEBRIS_SRC_PLAYER_H_
